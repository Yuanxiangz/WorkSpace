
define(['angular',
    'jquery',
    'kendo',
    'bootstrap',
    'uiBootstrap',
    'angularUiRouter',
    'angularHotkeys',
    'framework',
	'modules/trading/tradingMod',
	'modules/shell/shellMod',
	'modules/portfolio/portfolioMod',
	'modules/reporting/reportingMod',
	'modules/accounting/accountingMod', 
    'modules/compliance/complianceMod',
    'modules/operations/operationsMod',
	'scripts/directives/directives',
	'scripts/filters/filters'],
function (angular) {
	/**
	* @ngdoc overview
	 * @name webSpikeClientApp
	 * @description
	 * # webSpikeClientApp
	 *
	 * Main module of the application.
	 */
    var mainApp = angular.module('webSpikeClientApp', [
        'webSpike.framework',
        'ui.router',
        'cfp.hotkeys',
        'webSpike.trade',
        'webSpike.shell',
		'eze.accounting', 
		'eze.portfolio',
		'eze.reporting',
        'eze.compliance',
        'eze.operations',
		'directives',
		'filters']);

	mainApp.config(['$urlRouterProvider', '$stateProvider', 'hotkeysProvider', function ($urlRouterProvider, $stateProvider, hotkeysProvider) {
	   // $locationProvider.html5Mode(false).hashPrefix('!');

		hotkeysProvider.includeCheatSheet = true;

		$stateProvider.state('shell', {
			abstract: true,
            url: '/:shellType',
			templateUrl: 'modules/shell/_shell.html',
			controller: 'ShellController'
		});

        $stateProvider.state('home', {
        	parent: 'shell',
        	url: '/',
        	templateUrl: 'modules/shell/home/_home.html',
        	controller: 'HomeCtrl',
			data: {
		        display: "Home",
                icon: "images/Home_dark_icon.svg",
                hotkey: "home"
	        }
        });

		$stateProvider.state('messageCenter', {
			parent: 'shell',
			url: '/messageCenter',
			templateUrl: 'modules/shell/messageCenter/_messageCenter.html',
			controller: "MessageCenterCtrl",
			data: {
				display: "Message Center",
				icon: "images/MessageCenter_icon.svg",
				hotkey: "alt+m"
			}
		});

		$stateProvider.state('accounting', {
			url: '/accounting',
			parent: 'shell',
			templateUrl: 'modules/accounting/accounting.html',
			controller: 'accountingCtrl',
            redirectTo: 'accounting.summary',
			data: {
				display: "Accounting",
				icon: "images/Accounting_icon.svg"
			}
		});

		$stateProvider.state('accounting.summary', {
			url: '',
			parent: 'accounting',
            templateUrl: 'modules/accounting/summary/summary.html',
            controller: 'accountingSummaryCtrl',
			data: {
            	display: "Summary",
            	hotkey: "alt+a"
			}
		});

        $stateProvider.state('accounting.nav', {
            url: '/nav',
			parent: 'accounting',
            templateUrl: 'modules/accounting/nav/nav.html',
            controller: 'accountingNavCtrl',
			data: {
                display: "nav"
			}
		});

        $stateProvider.state('accounting.nav2', {
            url: '/nav2',
            parent: 'accounting',
            templateUrl: 'modules/accounting/nav2/nav2.html',
            controller: 'accountingNav2Ctrl',
            data: {
                display: "nav2"
            }
        });

        $stateProvider.state('accounting.odata', {
            url: '/odata',
            parent: 'accounting',
            templateUrl: 'modules/accounting/odata/odata.html',
            controller: 'accountingODataCtrl',
            data: {
                display: "odata"
            }
        });

        // Trading -----------------------------------------
        $stateProvider.state('trading', {
            url: '/trading',
            parent: 'shell',
            templateUrl: 'modules/trading/_trading.html',
            controller: 'TradingMainCtrl',
            redirectTo: 'trading.summary',
			data: {
                display: "Trading",
                icon: "images/Trading_icon.svg"
			}
		});

        $stateProvider.state('trading.summary', {
        	url: '',
			parent: 'trading',
	        templateUrl: 'modules/trading/tradeSummary/_tradeSummary.html',
	        controller: 'TradeSummaryCtrl',
			data: {
                display: "Summary",
				hotkey: "alt+t"
			}
        });

		$stateProvider.state('trading.blotter', {
			url: '/blotter',
			parent: 'trading',
            templateUrl: 'modules/trading/tradeBlotter/_tradeBlotter.html',
            controller: 'TradeBlotterCtrl',
			data: {
            	display: "Trade Blotter",
            	hotkey: "alt+b"
			}
        });

        $stateProvider.state('trading.allocations', {
        	url: '/allocations',
			parent: 'trading',
            templateUrl: 'modules/trading/allocations/_tradeAllocations.html',
            controller: 'TradeAllocationCtrl',
			data: {
				display: "Allocations"
			}
        });

        $stateProvider.state('trading.hypergrid', {
            url: '/hypergrid',
            parent: 'trading',
            templateUrl: 'modules/trading/hypergrid/_hypergrid-view.html',
            controller: 'HypergridCtrl',
            data: {
                display: "HyperGrid"
            }
        });

        $stateProvider.state('trading.chartWindow', {
            url: '/chart-window?DISP_NAME',
            parent: 'trading',
            templateUrl: 'modules/trading/widgets/highchart/_chart-view.html',
            controller: 'highchartWidgetCtrl',
            data: {
                display: "Highchart"
            }
        });

        $stateProvider.state('trading.equityOrderTicketWindow', {
            url: '/equity-order-ticket-window?DISP_NAME',
            parent: 'trading',
            templateUrl: 'modules/trading/widgets/ticket/_ticket-view.html',
            controller: 'ticketWidgetCtrl',
            data: {
                display: "Equity Order Ticket"
            }
        });

    	// Portfolio Management -----------------------------------------


        $stateProvider.state('portfolio', {
        	url: '/portfolio',
        	parent: 'shell',
        	redirectTo: 'portfolio.summary',
        	templateUrl: 'modules/portfolio/_portfolio.html',
        	controller: 'portfolioCtrl',
        	data: {
        		display: "Portfolio Management",
                icon: "images/Portfolio-icon.svg",
                hotkey: "alt+p"
        	}
        });

		$stateProvider.state('portfolio.summary', {
        	parent: 'portfolio',
        	url: '/summary',
        	templateUrl: 'modules/portfolio/summary/_summary-view.html',
        	controller: 'portfolioSummaryCtrl',
        	data: {
        		display: "Summary"
        	}
		});

		$stateProvider.state('portfolio.analytics', {
			parent: 'portfolio',
			url: '/analytics',
			templateUrl: 'modules/portfolio/analytics/_analytics-view.html',
			controller: 'analyticsCtrl',
			data: {
				display: "Analytics"
			}
		});

		$stateProvider.state('portfolio.odata', {
			parent: 'portfolio',
			url: '/odata',
			templateUrl: 'modules/portfolio/odata/_odata-view.html',
			controller: 'portfolioOdataCtrl',
			data: {
				display: "OData"
			}
		});

        // Reporting -----------------------------------------

        $stateProvider.state('reporting', {
            url: '/reporting',
            parent: 'shell',
            templateUrl: 'modules/reporting/_reporting.html',
            controller: 'reportingCtrl',
            redirectTo: 'reporting.reportList',
            data: {
                display: "Reporting",
                icon: "images/Reporting-icon.svg"
            }
        });

        $stateProvider.state('reporting.reportList', {
            parent: 'reporting',
            url: '/reports',
            templateUrl: 'modules/reporting/reportList.html',
            controller: 'reportListCtrl',
            data: {
                display: "List"
            }
        });

        $stateProvider.state('reporting.reportViewer', {
            parent: 'reporting',
            url: '/reports/:reportId',
            templateUrl: 'modules/reporting/reportViewer.html',
            controller: 'reportViewerCtrl',
            data: {
                display: "Report",
                hotkey: "alt+r"
            }
        });

        // Compliance -----------------------------------------
        $stateProvider.state('compliance', {
        	url: '/compliance',
        	parent: 'shell',
        	templateUrl: 'modules/compliance/_compliance.html',
        	controller: 'complianceCtrl',
        	data: {
        		display: "Compliance",
                icon: "images/Compliance_icon.svg",
                hotkey: "alt+c"
        	}
        });

        // Operations -----------------------------------------
        $stateProvider.state('operations', {
        	url: '/operations',
        	parent: 'shell',
        	templateUrl: 'modules/operations/_operations.html',
        	controller: 'operationsCtrl',
        	data: {
        		display: "Operations",
                icon: "images/Operations_icon.svg",
                hotkey: "alt+o"
        	}
        });

        // System -----------------------------------------
        $stateProvider.state('System', {
        	url: '/system',
        	parent: 'shell',
        	templateUrl: 'modules/framework/_system.html',
        	controller: 'systemCtrl',
        	data: {
        		display: "System",
                icon: "images/system-icon.svg",
                hotkey: "alt+s"
        	}
        });

        $urlRouterProvider.when('', '/app/');
        $urlRouterProvider.otherwise('/app/');
	}]);

	mainApp.controller("webSpikeController", ['$scope', '$location', 'settings', function ($scope, $location, settings) {
		$scope.name = settings.name;
	}]);

    //fix for this issue: https://github.com/angular-ui/ui-router/issues/948
    mainApp.run(['$rootScope', '$state', '$modal', function ($rootScope, $state, $modal) {
	    $rootScope.$on('$stateChangeStart', function (evt, to, params) {
	        if (to.redirectTo) {
	            evt.preventDefault();
                $state.go(to.redirectTo, params);
	        }
	    });


        //TODO: kjatti need to move this to a service of its own
        $rootScope.launchTicket = function (symbolToTrade) {
            $modal.open({
                //templateUrl: '/app/trading/chart-window?DISP_NAME=' + symbolToTrade,
                templateUrl: 'modules/trading/widgets/ticket/_ticket-view.html',
                controller: 'ticketWidgetCtrl',
                backdrop: 'static',
                size: 'lg',
                resolve: {
                    symbolToTrade: function () {
                        return symbolToTrade;
                    }
                }
	});
        };
    }]);

	return mainApp;

});