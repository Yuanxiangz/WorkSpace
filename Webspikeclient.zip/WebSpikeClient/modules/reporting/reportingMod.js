﻿'use strict';

define(['angular','reporting', './directives/report-viewer', './reportingCtrl', './reportList', './reportViewer', './widgets/reporting-dash'],
function (angular, reporting, ezeReportViewer, reportingController, reportListController, reportViewerController, reportingWidget) {

	var reporting = angular.module('eze.reporting', [reportingWidget.name]);

	reporting.controller('reportingCtrl', reportingController);
	reporting.controller('reportListCtrl', reportListController);
	reporting.controller('reportViewerCtrl', reportViewerController);

	reporting.directive('ezeReportViewer', ezeReportViewer);

	return reporting;

});
