﻿define(function () {
    'use strict';

    function EzeReportingController($http, $scope, settings) {
        
    	$scope.gridOptions = {
    	    dataSource:  {
    	        transport: {
    	            read: {
    	                url: settings.webApiEndpointHostname + '/WebApiService/reporting/api/ReportDefinitions',
    	                dataType: "json"
    	            },
    	            height: 500,
    	            scrollable: true,
    	            selectable: true
    	        }
    	    },
    	    sortable: true,
    	    pageable: true,
    	    columns: [
              { field: "Name", width: 100, template: "<a href='\\\\#/reporting/reports/#= Name #'> #= Name # </a>" }
    	    ]
    	};
    }

    EzeReportingController.$inject = ['$http', '$scope', 'settings'];

    return EzeReportingController;

});
