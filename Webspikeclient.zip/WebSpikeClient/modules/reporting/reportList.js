﻿define(function () {
    'use strict';

    function EzeReportingListController($http, $scope, settings) {

        $scope.gridOptions = {
            dataSource: {
                transport: {
                    read: {
                        url: settings.webApiEndpointHostname + '/WebApiService/reporting/api/ReportDefinitions',
                        dataType: "json"
                    },
                    height: 500,
                    scrollable: true,
                    selectable: true
                }
            },
            sortable: true,
            pageable: true,
            columns: [
              { field: "Name", width: 100, template: "<a ng-href='\\\\#/reporting/reports/#= Name #'> #= Name # </a>" }
            ]
        };

    }

    EzeReportingListController.$inject = ['$http', '$scope', 'settings'];

    return EzeReportingListController;

});