﻿define([], function () {
    'use strict';

    var ezeReportViewerCreate = function (scope, element, attrs) {

        element.telerik_ReportViewer(
            {   
                serviceUrl: 'http://localhost:8080/reporting/api/Reports/',
                templateUrl: 'vendor/telerik/reporting/9.0.15.324/Html5/templates/telerikReportViewerTemplate-9.0.15.324.html',
                reportSource: { report: 'invoice.trdx' },
                scaleMode: 'SPECIFIC',
                scale: parseFloat('1'),
                viewMode: 'INTERACTIVE'
            }
        );

    };

    var ezeReportViewer = function (settings) {
        return {
            restict: "E",
            template: "<div class='k-widget' style='height:100%'></div>",
            replace: true,
            scope:{ 
                reportId: '@'
            },
            link: function (scope, element, attrs) {

                scope.element = element;
                
                element.telerik_ReportViewer(
                    {
                        serviceUrl: settings.webApiEndpointHostname + '/WebApiService/reporting/api/Reports/',
                        templateUrl: 'vendor/telerik/reporting/9.0.15.324/Html5/templates/telerikReportViewerTemplate-9.0.15.324.html',
                        reportSource: { report: "invoice.trdx" },
                        scaleMode: 'SPECIFIC',
                        scale: parseFloat('1'),
                        viewMode: 'INTERACTIVE'
                    }
                );

                //scope.$watch(function (scope) { return scope.reportId; }, function (newValue, oldValue) {
                //    $scope.element.telerik_ReportViewer().reportSource = { report: $scope.reportId + '.trdx' };
                //})
            }
        }
    };


    return ezeReportViewer;

});