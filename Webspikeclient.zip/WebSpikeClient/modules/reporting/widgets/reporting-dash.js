﻿define(['angular', 'angularDashboard'],
function (angular) {

	var widget = angular.module('eze.reporting.widget.reporting', ['adf.provider']);

	widget.config(function (dashboardProvider) {
		dashboardProvider
			.widget('reportingWidget', {
				title: 'Reporting',
				image: 'images/reporting-icon.svg',
				description: 'Reporting Summary',
				templateUrl: 'modules/reporting/widgets/_reporting-dash.html',
				controller: 'ReportingWidgetController',
				controllerAs: 'Reporting',
				config: { }
			});
	});

	widget.controller('ReportingWidgetController', function ($scope, config) {
		
		$scope.title = "TBD";
	});

	return widget;

});