﻿define(function () {
    'use strict';

    function EzeReportController($scope, $stateParams) {
        $scope.reportId = $stateParams.reportId;
    }

    EzeReportController.$inject = ['$scope', '$stateParams'];

    return EzeReportController;

});
