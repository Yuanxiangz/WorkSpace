﻿
define(function () {
    'use strict';

    function TradingAllocationController($scope) {
        $scope.test = 'test';
    }

    TradingAllocationController.$inject = ['$scope'];

    return TradingAllocationController;

});
