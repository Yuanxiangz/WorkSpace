﻿
define(['angular',
    './tradingCtrl',
    './tradeBlotter/tradeBlotterCtrl',
    './tradeSummary/tradeSummaryCtrl',
	'./allocations/tradeAllocationCtrl',
    './widgets/tradingWidgets',
    './hypergrid/hypergridCtrl',
    './widgets/order-commit/orderCommitDropCtrl'],
function (angular,
    TradingController,
    TradeBlotterController,
    TradeSummaryController,
    TradeAllocationController,
    tradingWidgets,
    HypergridController,
    orderCommitDropController) {
    'use strict';
	var trading = angular.module('webSpike.trade', [tradingWidgets.name]);

	trading.controller('TradingMainCtrl', TradingController);
	trading.controller('TradeBlotterCtrl', TradeBlotterController);
	trading.controller('TradeSummaryCtrl', TradeSummaryController);
	trading.controller('TradeAllocationCtrl', TradeAllocationController);
	trading.controller('HypergridCtrl', HypergridController);
	trading.controller('orderCommitDropCtrl', orderCommitDropController);


	return trading;
});
