﻿
define(function () {
    'use strict';

    function TradingSummaryController($scope) {
        $scope.model = {};

        $scope.setDashboardModel = function () {
            $scope.model = {
                structure: "TradingDashBoard",
             
                rows: [
                    {
                        columns: [
                            {
                                styleClass: "col-md-12 no-padding",
                                widgets: [{
                                    type: "highchartWidget",
                                    title: "HighChart"
                                }
                                ]
                            }
                        ]
                    },
                    {
                        columns: [
                            {
                                styleClass: "col-md-4 no-padding",
                                widgets: [{
                                    type: "watchlistWidget",
                                    title: "My Watchlist"
								    }
						    	]
						    },
						    {
						    	styleClass: "col-md-4 no-padding",
						    	widgets: [
								    {
								    	type: "tradingMarketOverview",
								    	title: "Market Overview"
								    }
						    	]
                            },
                            {
                            	styleClass: "col-md-4 no-padding",
                            	widgets: [{
                            		type: "tradingHeatmapWidget",
                            		title: "Heatmap"
                            	}]
                            }
                        ]
                    },
	                {
	                	columns: [
							{
								styleClass: "col-md-12 no-padding tradingWorkflowsWide",
								widgets: [{
									type: "tradingWorkflowsWidget",
									title: "Trade Workflows"
								}]
							}
	                	]
	                }
                ]
            };
		};


        $scope.init = function () {
            $scope.setDashboardModel();
		};

        $scope.init();
    }

    TradingSummaryController.$inject = ['$scope'];

    return TradingSummaryController;

});
