define([], function() {
	'use strict';

	var watchlistSvc = function ($q, storage, settings) {
		var defaultValues = {
			columns: ['DISP_NAME', 'TRDPRC_1', 'CHANGE_LAST', 'TRDPRC_2', 'ACVOL_1', 'SYMBOL_DESC'],
			symbols: ['AAPL', 'HA', 'GOOG', 'CSCO', 'UA', 'YHOO']
		};

		var rootURL = settings.apiEndpointHostname;

		this.getDefaultColumns = function () {
			return defaultValues.columns;
		};
		this.getDefaultSymbols = function () {
			return defaultValues.symbols;
		};

		this.getFields = function (glx2) {
			var deferred = $q.defer();
			var fieldsURL = rootURL + 'data/data.fields?feature=USER&glx=' + glx2;

			storage.async(fieldsURL,
				function(data) {
					deferred.resolve(data);
				},
				function (data, status, headers, config) {
					deferred.reject(status);
				}
			);

			return deferred.promise;
		};

		this.getSymlist = function(glx2, symbols, columns) {
			var deferred = $q.defer();
			var symlistUrl = rootURL + 'data/quote.symlist?feature=WATCHLIST' + '&glx=' + glx2 
				+ '&symbols=' + encodeURIComponent(symbols) 
				+ '&columns=' + encodeURIComponent(columns);

			storage.async (symlistUrl,
				function(data, status, headers, config) {
					deferred.resolve(data);
				},
				function(data, status, headers, config) {
					deferred.reject(status);
				}

			);

			return deferred.promise;
		};

		this.getSymbolInfo = function (glx2, symbol) {
			var arrColumns = ['RIC_CODE', 'BLOOMBERG_CODE', 'CUSIP', 'DISP_NAME', 'ACVOL_1',
                       'NETCHNG_1', 'HIGH_1', 'LOW_1', 'BID','BIDSIZE', 'ASK', 'ASKSIZE',
                       'SYMBOL_DESC','EXCH_NAME', 'STYP', 'PCTCHNG', 'TRDPRC_1', 'TRD_UNITS'];

			var deferred = $q.defer();
			var getSymInfoUrl = rootURL + 'data/quote.symlist?feature=SYMBOL' + '&glx=' + glx2 
	                    + '&symbols=' + encodeURIComponent(symbol)
	                    + '&columns=' + encodeURIComponent(arrColumns);
			storage.async(getSymInfoUrl,
				function(data, status, headers, config) {
					deferred.resolve(data.Data);
				}, function(data, status, headers, config){
					deferred.reject(status);
				}

			);

			return deferred.promise;
		};
		this.getIntraday = function (glx2, symbols) {
			var deferred = $q.defer();
			var today = new Date();

			var intraDayURL = rootURL + 'data/quote.intraday?feature=CHART' + '&glx=' + glx2
                + '&symbols=' + encodeURIComponent(symbols)
                + '&daysback=1'
                + '&startdate=' + today.toLocaleDateString()  //this value actually doesn't even matter, but is needed in the query
                + '&stopdate=' + today.toLocaleDateString()
                + '&dateperiod=' + 3
                + '&minuteinterval=' + 1;

            storage.async(intraDayURL,
            	function (data, status, headers, config) {
            		deferred.resolve(data);
            	},
            	function (data, status, headers, config) {
            		deferred.reject(status);
            	}
            );

            return deferred.promise;
		};


	};	//end svc


	watchlistSvc.$inject = ['$q', 'storage', 'settings'];

	return watchlistSvc;
});
