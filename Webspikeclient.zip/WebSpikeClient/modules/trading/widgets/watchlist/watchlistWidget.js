
define(['angular', 'angularDashboard', 'sortable', 'kendo', 'jquery', 'lodash'],
function (angular, adb, sort, kendoPlaceholder, $, _) {
  'use strict';
	var watchlistWidget = angular.module('webSpike.trading.widget.watchlist', ['adf.provider', 'kendo.directives']);

	var x = sort;

	watchlistWidget.config(function (dashboardProvider) {
		dashboardProvider
			.widget('watchlistWidget', {
			    title: 'My Watchlist',
				description: 'Watchlist',
				templateUrl: 'modules/trading/widgets/watchlist/_watchlist-view.html',
				controller: 'WatchlistWidgetCtrl',
				config: {
				},
				edit: {	}
			});
	});

	watchlistWidget.controller('WatchlistWidgetCtrl',
        ['$scope',
        'watchlistSvc',
        '$q',
        'auth',
        'streaming',
        '$rootScope',
        'pubsub',
        'settings',
        function ($scope,
            watchlistSvc,
            $q,
            auth,
            streaming,
            $rootScope,
            pubsub,
            settings) {

            var isElectron = true;
            try {
                window.$ = window.jQuery = require('./vendor/jquery/2.1.4/jquery.min');
                Sortable = require('./vendor/sortable/1.1.1/Sortable.min');
                require('remote').new
            }
            catch (e) {
                isElectron = false;
            }

	    $scope.defaultColumns = watchlistSvc.getDefaultColumns();
	    $scope.defaultSymbols = watchlistSvc.getDefaultSymbols();
	    $scope.glx2 = '';

	    $scope.watchlistColumns = [];
	    $scope.watchlistData = [];
	    $scope.indexedChartData = {};

	    $scope.isEnteringNewSymbol = false;

	    $scope.settings = settings.getSettingsKeys;


	    $scope.symbolClicked = function symbolClicked(symbol) {
	        pubsub.publish($scope.settings.chart.createchart, [symbol], true);
	        if (isElectron) {
// ReSharper disable Es6Feature
	            //var ipc = require('ipc');
	            //var arg = {};
	            //arg.DISP_NAME = symbol;
	            //ipc.send('launchChartWindow', arg);
// ReSharper restore Es6Feature
	        }
	    };

	    $scope.getFields = function () {
	    	var deferred = $q.defer();

	    	watchlistSvc.getFields($scope.glx2).then(
	    		function(data) {
                    if (data.Data && data.Data.symlist) {
                        var symData = data.Data.symlist;
                        for (var field in symData) {
                            var curr = symData[field];
                            if ($scope.defaultColumns.indexOf(curr.Name) > -1) {    //only show column if it was requested
                                var currObj = { field: curr.Name, title: curr.Display };
                                $scope.watchlistColumns.push(currObj);  //push to columns array for kendo grid
                            }
                        }
                        deferred.resolve('success');
                    } else {
                        deferred.resolve('noresults');
                    }
	    		}, function(errorStatus) {
	    			console.log(errorStatus);
	    			deferred.resolve('error');
	    		}

	    	);

	        return deferred.promise;
	    };

	    $scope.getWatchlistData = function () {
	        var deferred = $q.defer();

	        watchlistSvc.getSymlist($scope.glx2, $scope.defaultSymbols.join(','), $scope.defaultColumns.join(',')).then(
	        	function (data) {
        			$scope.watchlistData = data.Data;
                	deferred.resolve('success');
	        	}, function (errorStatus) {
	        		console.log('error retrieving watchlist: ' + errorStatus);
	        		deferred.resolve('error');
	        	}
	        );
	        return deferred.promise;
	    };

	    $scope.init = function () {
            auth.getGlxToken()
                .then(function (glx) {
                    if (glx) {
                        $scope.glx2 = glx;

                        $scope.getFields().then(function (msg) {
                            if (msg === 'success') {
                                $scope.getWatchlistData()
                                .then(function () {
                                    streaming.init()
                                    .then(function () {
                                        $scope.defaultSymbols.forEach(function (symbol) {
                                            $scope.subscribeToSymbol(symbol);
                                        });
                                        $scope.getIntraday($scope.defaultSymbols);
                                    });
                                });
                            }
                        });
                    }
                });
        };

	    $scope.subscribeToSymbol = function (symbol) {
	        streaming.subscribe('quote', { symbol: symbol }, function (data) {
	            if (data) {
	                //console.log(data);
	                var symbol = data.DISP_NAME;
	                var pairs = _.pairs(data);
	                var symbolIndex = _.findIndex($scope.watchlistData, { DISP_NAME: symbol });
	                $scope.$apply(function () {
	                    _.forEach(pairs, function (val, key) {
	                        $scope.watchlistData[symbolIndex][val[0]] = val[1];
	                    });
	                });
	            }
	        }).then(function (subInfo) {
	            if (subInfo) {
	                //console.log(subInfo);
	            }
	        });
	    };

        //takes an array of symbol/symbols
	    $scope.getIntraday = function (symbols) {
	        var fullSymList = symbols.join(',');
	        watchlistSvc.getIntraday($scope.glx2, fullSymList).then(
	        	function (data) {
	        		if (data && data.Data.length > 0) {
                		$scope.indexedChartData = _.groupBy(data.Data, function (sym) {  //index by symbol name
                			return sym[0].DISP_NAME;
                		});
                	} else {
                		console.error('no data from intraday');
                	}
	        	}, function (errorStatus) {
	        		console.log('error getting intraday: ' + errorStatus);
	        	}
            );
	    };

	    $scope.addSymbol = function (symbol) {
	        if ($scope.defaultSymbols.indexOf(symbol) > -1) {
	            return;
	        }
	        var columns = _.map($scope.watchlistColumns, function (column) {
            		   return column.field;
            }).join();

	        watchlistSvc.getSymlist($scope.glx2, symbol, columns).then(
	        	function(data) {
        			if (data && data.Data.length > 0) {
        				$scope.watchlistData.push(data.Data[0]);
        				$scope.defaultSymbols.push(symbol);
        				$scope.subscribeToSymbol(symbol);
        				$scope.getIntraday(symbol.split(''));
        				$scope.addSymbolField = '';
        			} else {
        				console.error('No Data returned from Symlist Call');
        			}
	        	}, function (errorStatus) {
	        		console.log('error getting symlist: ' + errorStatus);
	        	}
	        );
	    };

	    $scope.redOrGreen = function (netchg) {
	        netchg = parseFloat(netchg);

	        if (netchg < 0) {
	            return '#D14B4C';
	        } else if (netchg > 0) {
	            return '#7FC241';
	        } else {
	            return '#414141';
	        }
	    };

	    $scope.redOrGreenString = function (netchg) {
	        netchg = parseFloat(netchg);

	        if (netchg < 0) {
	            return 'red-line';
	        } else if (netchg > 0) {
	            return 'green-line';
	        } else {
	            return 'black-line';
	        }
	    };

	    $scope.upOrDown = function (netchg) {
	        netchg = parseFloat(netchg);

	        if (netchg < 0) {
	            return 'glyphicon glyphicon-triangle-bottom';
	        } else if (netchg > 0) {
	            return 'glyphicon glyphicon-triangle-top';
	        } else {
	            return 'glyphicon glyphicon-minus';
	        }
	    };

	    $scope.init();

	    $scope.enterNewSymbol = function () {
	        $scope.isEnteringNewSymbol = true;
	    };

	    $scope.addNewSymbolFromTextBox = function () {
	        $scope.addSymbol($scope.addSymbolField);
	        $scope.isEnteringNewSymbol = false;
	    };

	    $scope.onTradeContextMenuSelect = function (e) {
	        switch (e.item.attributes['contextmenu-id'].value) {
	            case 'createTrade':
	                {
	                    var modelJson = e.target.attributes['contextmenu-model'].value;
	                    var model = JSON.parse(modelJson);
	                    if (isElectron) {
	                        // ReSharper disable Es6Feature
	                        var ipc = require('ipc');
	                        var arg = {};
	                        arg.DISP_NAME = model.DISP_NAME;
	                        ipc.send('launchEquityOrderTicketWindow', arg);
	                        // ReSharper restore Es6Feature
	                    } else {
	                        $rootScope.launchTicket(model.DISP_NAME);
	                    }
	                    break;
	                }
	            case 'openChart':
                    {
                        var modelJson = e.target.attributes['contextmenu-model'].value;
                        var model = JSON.parse(modelJson);
                    
                        if (isElectron) {
                            // ReSharper disable Es6Feature
                            var ipc = require('ipc');
                            var arg = {};
                            arg.DISP_NAME = model.DISP_NAME;
                            ipc.send('launchChartWindow', arg);
                            // ReSharper restore Es6Feature
                        } else {
                            pubsub.publish($scope.settings.chart.createchart, [model.DISP_NAME], true);
                        }
                        break;
                    }
	            
	        default:
	        }
	    };

	}]);

	return watchlistWidget;
});
