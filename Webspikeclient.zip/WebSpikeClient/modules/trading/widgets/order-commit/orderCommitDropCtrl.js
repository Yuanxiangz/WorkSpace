define([], function () {
    'use strict';

    function orderCommitDropController($scope, routes, order, pubsub, ticketSvc, auth) {
        $scope.routes = routes;
	    $scope.order = order;
	    $scope.order.selectedRoute = "-1";
	    $scope.order.BBCDArr = $scope.order.BBCD.split(';');

	    $scope.closeModal = function () {
	        $scope.$close();
	    }
	    $scope.submitOrder = function () {

	    	auth.getGlxToken()
            .then(function gotGlxToken(glx) {
            	$scope.order.EXIT_VEHICLE = $scope.order.selectedRoute.trim();	//set the route
            	var orderToSubmit = $scope.buildStagedOrder($scope.order);
            	ticketSvc.submitOrder(glx, 'rotr_dev_locale', orderToSubmit,
            		function success(data){
            			pubsub.publish('newlyEnteredTrade', []);	        
	        			$scope.closeModal();
            		},
            		function error(err) {
            			$scope.closeModal();
            		}
            )});	        
	    };

	    $scope.cancelOrder = function () {
	        $scope.closeModal();
	    }


        $scope.buildStagedOrder = function buildStagedOrder (order) {
            var orderToReturn = {
				ACCT_TYPE: 1,
				ACCT_TYPE_STR: "Cash",
				BANK: $scope.order.BBCDArr[0],
			 	BBCD: {ShortName: $scope.order.BBCD},
				BRANCH: $scope.order.BBCDArr[1],
				BUYORSELL: $scope.order.buyorsell,
				BaseCode: 109,
				CUSTOMER: $scope.order.BBCDArr[2],
				DEPOSIT: $scope.order.BBCDArr[3],
				DISP_NAME: $scope.order.dispName,
				DISP_PRICE: 0,
				EXCHANGE: "NYS",
				EXIT_VEHICLE: $scope.order.EXIT_VEHICLE,
				//EXIT_VEHICLE_FULL: Object
				GOOD_UNTIL: "Day",
				ORDER_DISP_PRICE: 0,
				ORDER_TYPE: "Market",
				PRICE_TYPE: "Market",				
				STYP: 1,
				TO_OPEN_POS: 0,
				VOLUME: $scope.order.volume.split(' ')[0] //ex: "25 shares"            	
            }

            return orderToReturn
        }
    }

    orderCommitDropController.$inject = ['$scope', 'routes', 'order', 'pubsub', 'ticketSvc', 'auth'];

    return orderCommitDropController;

});
