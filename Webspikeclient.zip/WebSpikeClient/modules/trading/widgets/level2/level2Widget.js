'use strict';

define(['angular', 'angularDashboard', 'lodash'],
function (angular,adb,_) {
	var level2Widget = angular.module('webSpike.trading.widget.level2', ['adf.provider']);

	level2Widget.config(function (dashboardProvider) {
		dashboardProvider
			.widget('level2Widget', {
			    title: 'Level 2',
				description: 'Level 2 Data',
				templateUrl: 'modules/trading/widgets/level2/_level2-view.html',
				controller: 'level2WidgetController'
			});
	});

	level2Widget.controller('level2WidgetController', ['$scope', 'pubsub', 'settings', 'streaming', 'auth', 
        function ($scope, pubsub, settings, streaming, auth) {

        $scope.glxToken = '';

        $scope.showAjaxLoading = false;
        $scope.config = {
            depth: 24,
            level2Enabled: false,
            level2UserEnabled: true,
            level2Available: true,
            isFullScreen: false
        };

        $scope.pubsubHandle = {
            symbol: null,
            disconnected: null,
            connected: null
        };

        $scope.settings = null;

        $scope.level2Data = {
            symbol: '',
            subInfo: null,
            askData: {},
            bidData: {}
        };

        //#endregion

        //#region Utility Functions

        $scope.closeAlert = function (index) {
            $scope.form.message.splice(index, 1);
        };

        $scope.setDepth = function () {
            var rowheight = 20; // ref in css
            var height_fix = 42;
            var height = ($("#level2-container").height() - height_fix);
            $scope.config.depth = ((Math.ceil(height / rowheight)) - 1);
        }

        $scope.getBaseClass = function (price) {
            return Math.floor((price * 100) % 100);
        };

        $scope.unsubscribe = function () {
            if ($scope.level2Data.subInfo) {
                streaming.unsubscribe($scope.level2Data.subInfo);
                $scope.level2Data.subInfo = null;
                $scope.level2Data.askData = {};
                $scope.level2Data.bidData = {};
            }
        };

        $scope.disconnected = function () {
            if (streaming.available()) {
                $scope.config.level2UserEnabled = false;
            } else {
                $scope.config.level2Available = false;
            }
            $scope.unsubscribe();
        };

        $scope.connected = function () {
            $scope.config.level2UserEnabled = true;
            $scope.config.level2Available = true;
            $scope.getLevel2Data();
        };

        //#endregion

        //#region Functions
        $scope.addLevel2DataToChart = function (data) {
            var i, init, prop, compact;
            if (data && data.length >= 1) {
                for (i = 0; i < data.length; i++) {
                    if (data[i].QUOTE_UPDATE_TYPE && data[i].QUOTE_UPDATE_TYPE === 7) {
                        if ($scope.level2Data.askData.hasOwnProperty(data[i].MKT_MKR_ID)) {
                            delete $scope.level2Data.askData[data[i].MKT_MKR_ID];
                        }
                        if ($scope.level2Data.bidData.hasOwnProperty(data[i].MKT_MKR_ID)) {
                            delete $scope.level2Data.bidData[data[i].MKT_MKR_ID];
                        }
                    } else if (data[i].QUOTE_UPDATE_TYPE && data[i].QUOTE_UPDATE_TYPE !== 2) {
                        //console.log(data);
                    }

                    init = false;

                    if (!$scope.level2Data.bidData[data[i].MKT_MKR_ID] &&
                        data[i].MKT_MKR_BID && data[i].MKT_MKR_BID > 0 &&
                        data[i].MKT_MKR_BID !== '.00' && data[i].MKT_MKR_BIDSIZE) {

                        $scope.level2Data.bidData[data[i].MKT_MKR_ID] = data[i];
                        init = true;
                    }
                    if (!$scope.level2Data.askData[data[i].MKT_MKR_ID] &&
                        data[i].MKT_MKR_ASK && data[i].MKT_MKR_ASK > 0 &&
                        data[i].MKT_MKR_ASK !== '.00' && data[i].MKT_MKR_ASKSIZE) {

                        $scope.level2Data.askData[data[i].MKT_MKR_ID] = data[i];
                        init = true;
                    }

                    if (!init) {
                        compact = _.each(data[i], function (v, k) {
                                    if (!v)
                                        delete data[i][k];
                        });

                        if ($scope.level2Data.bidData[data[i].MKT_MKR_ID] &&
                            $scope.level2Data.askData[data[i].MKT_MKR_ID]) {

                            for (prop in compact) {
                                $scope.level2Data.bidData[data[i].MKT_MKR_ID][prop] = compact[prop];
                                $scope.level2Data.askData[data[i].MKT_MKR_ID][prop] = compact[prop];
                            }
                        } else if ($scope.level2Data.bidData[data[i].MKT_MKR_ID]) {
                            for (prop in compact) {
                                $scope.level2Data.bidData[data[i].MKT_MKR_ID][prop] = compact[prop];
                            }

                        } else if ($scope.level2Data.askData[data[i].MKT_MKR_ID]) {
                            for (prop in compact) {
                                $scope.level2Data.askData[data[i].MKT_MKR_ID][prop] = compact[prop];
                            }
                        }
                    }
                }
            }
        };

        $scope.getLevel2Data = function () {
            streaming.subscribe('level2',
                { symbols: [$scope.level2Data.symbol] },
                function (data) {
                    if (!data || data.length <= 0) {
                        console.log('error getting level2 data');
                    } else {
                        $scope.$apply($scope.addLevel2DataToChart(data));
                    }
                }).then(function (subInfo) {
                    $scope.level2Data.subInfo = subInfo;
                });
        };

        $scope.updateSymbol = function (sym) {
            var orderObj = JSON.parse(sym)[0];
            sym = orderObj.DISP_NAME;

            if (sym && $scope.level2Data.symbol != sym) {
                $scope.level2Data.symbol = sym;
                $scope.unsubscribe();
                $scope.getLevel2Data();
            }
        };

	    $scope.final = function () {
            $scope.unsubscribe();

	        pubsub.unsubscribe($scope.pubsubHandle.symbol);      //unsubscribe on $destroy
            pubsub.unsubscribe($scope.pubsubHandle.disconnected);
            pubsub.unsubscribe($scope.pubsubHandle.connected)
	    };

	    $scope.init = function () {
	        auth.getGlxToken().then(function (result) {		//first get the glx2 token
                if (result && result !== 'error') {
                    $scope.glxToken = result;
                    $scope.settings = settings.getSettingsKeys;
                    streaming.init()
                    .then(function() {
                        $scope.pubsubHandle.disconnected =
                            pubsub.subscribe($scope.settings.streaming.disconnected, $scope.disconnected);
                        $scope.pubsubHandle.connected =
                            pubsub.subscribe($scope.settings.streaming.connected, $scope.connected);
                        $scope.pubsubHandle.symbol =
                            pubsub.subscribe($scope.settings.tradeblotter.symbolselected, $scope.updateSymbol);
                        
                        $scope.$on('$destroy', $scope.final);

                    });
                }
            });
	    };

	    $scope.init();


	}]);

	return level2Widget;
});

