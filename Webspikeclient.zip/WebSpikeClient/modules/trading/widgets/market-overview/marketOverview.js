﻿define(['angular', 'lodash', 'angularDashboard', 'kendo', './marketDataApiHelper'],
function (angular, _, adb, kendo, mktDataApiHelper) {
    'use strict';
	var marketOverview = angular.module('webSpike.trading.widget.mktOverview', ['adf.provider', 'kendo.directives']);

	marketOverview.config(function (dashboardProvider) {
		dashboardProvider
			.widget('tradingMarketOverview', {
				title: 'Market Overview',
				description: 'Markets Overview',
				templateUrl: 'modules/trading/widgets/market-overview/_view.html',
				controller: 'TradingMarketOverviewCtrl'
			});
	});

	marketOverview.controller("TradingMarketOverviewCtrl", ["$scope", "$http", "$q","auth", "settings", function ($scope, $http,$q, auth, settings) {

		$scope.dataApiHelper = new mktDataApiHelper(settings.apiEndpointHostname);

		$scope.indexLiveQuotes = []; //

		$scope.NASDAQcolor = "#E828C7";
		$scope.DOWcolor = "#FF6B2C";

		$scope.indexHistoricalData = {
			intraday: [],
			oneWeek: [],
			oneMonth: [],
			threeMonths: [],
		};

		$scope.indexChartSeries = [
			{
				field: 'SETTLE',
				markers: {
					visible: false
				},
				tooltip: {
					visible: true,
					template: "#= kendo.format('{0:MM/dd/yyyy}',dataItem.TRD_DATE) # #= dataItem.TRDTIM_1 ? dataItem.TRDTIM_1 : '' # - ${value}"
				}
			}
		];

		$scope.getQuotes = function (symbols) {
			var deferred = $q.defer();
			var defaultColumns = ['DISP_NAME', 'TRDPRC_1', 'CHANGE_LAST', 'TRDPRC_2', 'ACVOL_1', 'SYMBOL_DESC'];
			var encodedSymbols = encodeURIComponent(symbols.join(',')); //convert to csv's and url encode
			var encodedColumns = encodeURIComponent(defaultColumns.join(','));


			auth.getGlxToken()
				.then(function (glx) {
					var getWatchlistDataUrl = settings.apiEndpointHostname + 'data/quote.symlist?feature=WATCHLIST&glx=' + glx + '&symbols=' + encodedSymbols + '&columns=' + encodedColumns;   //this will be stored in a config
					$http.get(getWatchlistDataUrl)
						.success(function (data, status, headers, config) {
						    $scope.indexLiveQuotes = _.sortBy(data.Data, 'SYMBOL_DESC');
						    var DOWindexIndex = _.findIndex($scope.indexLiveQuotes, { DISP_NAME: '$DJI' });
						    var NASDAQindexIndex = _.findIndex($scope.indexLiveQuotes, { DISP_NAME: '$NDX.X' });
						    $scope.indexLiveQuotes[DOWindexIndex].color = $scope.DOWcolor;
						    $scope.indexLiveQuotes[NASDAQindexIndex].color = $scope.NASDAQcolor;
						})
						.error(function () {

						});
				});

		};

		$scope.loadChart = function (uriBuilderFunction, duration, durationTag) {
			auth.getGlxToken()
				.then(function (glx) {
					var chartDataUrl = "";

					$scope.activeTimeframe = durationTag;


					var symbols = _(symbolsList).map(function(symb) {
						return symb.symbol;
						});

					chartDataUrl = duration ? uriBuilderFunction(symbols, glx, duration): uriBuilderFunction(symbols, glx);
					$http.get(chartDataUrl)
						.success(function (data, status, headers, config) {
							var allData = [];
							_.forEach(data.Data, function (list) {
								allData = allData.concat(list);
							});

							var getMin = function getMin(collection, property) {
							    return _.min(collection, function (datapoint) {
							        return datapoint[property];
							    })[property];
							};

							var getMax = function getMin(collection, property) {
							    return _.max(collection, function (datapoint) {
							        return datapoint[property];
							    })[property];
							};

							var seriesData = _(allData)
                            .map(function transformAllData(datapoint) {
							    datapoint.TRD_DATE = new Date(datapoint.TRD_DATE);
							    return datapoint;
                            })
                            .groupBy(function groupAllData(dataPoint) {
							    return dataPoint.DISP_NAME;
							}).value();

							var minMultiplier = .99;
							var maxMultiplier = 1.01;

							var tooltip = {
							    visible: true,
							    template: "#= kendo.format('{0:MM/dd/yyyy}',dataItem.TRD_DATE) # #= dataItem.TRDTIM_1 ? dataItem.TRDTIM_1 : '' # - ${value}"
							};

							var series = _.map(symbolsList, function constructSeries(symbol) {
							    var symbolData = symbol;
							    symbolData.field = "SETTLE";
							    symbolData.title = { text: symbol.name };
							    symbolData.data = seriesData[symbol.symbol];
							    symbolData.axis = symbol.name;
							    symbolData.tooltip = tooltip;
							    symbolData.color = symbol.color;
							    return symbolData;
							});

							var valueAxes = _.map(symbolsList, function constructValueAxes(symbol) {
							    var symbolData = {};
							    symbolData.name = symbol.name;
							    symbolData.min = getMin(seriesData[symbol.symbol], "SETTLE") * minMultiplier;
							    symbolData.max = getMax(seriesData[symbol.symbol], "SETTLE") * maxMultiplier;
							    symbolData.visible = true;
							    symbolData.minorGridLines = { visible: false };
							    symbolData.majorGridLines = { visible: true };
							    symbolData.color = symbol.color;
							    symbolData.labels = {
							        format: "{0:n0}"
                                    
							    }
							    return symbolData;
							});

							var otherAxes = {
							    visible: false,
							    minorGridLines: { visible: false },
							    majorGridLines: { visible: false },
							    axisCrossingValues: [0, seriesData[symbolsList[0].symbol].length]
							};

							var marketOverviewChart = $("#marketOverviewChart").kendoChart({
							    legend: {
							        visible: false
							    },
							    seriesDefaults: {
							        type: 'line',
                                    markers: 'false'
							    },
							    series: series,
							    valueAxes: valueAxes,
							    categoryAxis: otherAxes
							});                            
						})
						.error(function (data, status, headers, config) {
							console.error('error retrieving watchlist data');
						});
				});
		};


		// make this configurable
		var symbolsList = [
			{
				name: 'NASDAQ',
				symbol: '$NDX.X',
				color: "#E828C7"
			},
			{
				name: "DOW",
				symbol: "$DJI",
				color: "#FF6B2C"
			}
		];


		$scope.colorMap = {};
		_.forEach(symbolsList, function (record) {
			$scope.colorMap[record.symbol] = {};
			$scope.colorMap[record.symbol].color = record.color;
			$scope.colorMap[record.symbol].style = '{color:' + record.color +'}';
		});

		$scope.init = function () {
			$scope.getQuotes(_(symbolsList).map(function (symb) {
				return symb.symbol;
			}));
			$scope.loadChart($scope.dataApiHelper.intradayDataUri, null, '1D');
		};

		$scope.init();
	}]);

	return marketOverview;
});