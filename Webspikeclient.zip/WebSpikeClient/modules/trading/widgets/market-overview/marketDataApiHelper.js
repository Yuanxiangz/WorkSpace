﻿'use strict';

define(['moment'], function (moment) {

	var exportClosure =  (function (marketDataBaseUri) {
		var self = this;

		this.baseUrl = marketDataBaseUri;

		this.intradayQuotesEndpoint = "data/quote.intraday";
		this.dailyQuotesEndpoint = "data/quote.daily";

		var getIntradayDataQuery = function (symbols, glx, minuteInterval) {
			minuteInterval = minuteInterval ? minuteInterval : 1; //default to 1 minutes
			var now = moment();
			var stopDate = now.format("MM/DD/YYYY");
			return self.baseUrl + self.intradayQuotesEndpoint + "?" + getChartDataQuery(symbols, stopDate, stopDate, glx, 3, minuteInterval,1); //startdate same as stop date
		};

		var getLastNDaysDataQuery = function(symbols, glx,days) {
			var now = moment();
			var stopDate = now.format("MM/DD/YYYY");
			var startDate = now.subtract(days, 'days').format("MM/DD/YYYY");
			return self.baseUrl + self.intradayQuotesEndpoint + "?" + getChartDataQuery(symbols, startDate, stopDate, glx, 3, 30,days);
		};


		var getLastNMonthsDataQuery = function(symbols, glx,months) {
			var now = moment();
			var stopDate = now.format("MM/DD/YYYY");
			var startDate = now.subtract(months, 'months').format("MM/DD/YYYY");
			return self.baseUrl + self.intradayQuotesEndpoint + "?" + getChartDataQuery(symbols, startDate, stopDate, glx, 3, 60);
		};

		var getLastNYearsDataQuery = function(symbols, glx,years) {
			var now = moment();
			var stopDate = now.format("MM/DD/YYYY");
			var startDate = now.subtract(years, 'years').format("MM/DD/YYYY");
			return self.baseUrl + self.dailyQuotesEndpoint + "?" + getChartDataQuery(symbols, startDate, stopDate, glx);
		};

		var getChartDataQuery = function (symbols, startDate, stopDate, glx, datePeriod, minuteInterval, daysback) {
			var query = {
				feature: "CHART",
				symbols: symbols,
				startdate: startDate,
				stopdate: stopDate,
				glx: glx,
                daysback : daysback ? daysback : null,
				dateperiod: datePeriod ? datePeriod : 0,
				minuteinterval: minuteInterval
			};

			var serialize = function(obj) {
				var str = [];
				for (var p in obj)
					if (obj.hasOwnProperty(p)) {
						str.push(p + "=" + obj[p]);
					}
				return str.join("&");
			};

			return serialize(query);
		};

		return {
			intradayDataUri: getIntradayDataQuery,
			lastNDaysDataUri: getLastNDaysDataQuery,
			lastNMonthsDataUri: getLastNMonthsDataQuery,
			lastNYearsDataUri: getLastNYearsDataQuery
		}
	});

	return exportClosure;
});