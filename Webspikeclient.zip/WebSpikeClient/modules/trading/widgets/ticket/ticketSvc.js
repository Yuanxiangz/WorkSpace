﻿define([], function () {
    'use strict';

    var ticketSvc = function (storage, settings) {
        var config = {
            columns: ['DISP_NAME', 'TRDPRC_1', 'CHANGE_LAST', 'TRDPRC_2', 'ACVOL_1', 'SYMBOL_DESC'],
            orderTypes: ['Limit', 'Market', 'StopLimit', 'Stop'],
            actions: ['Buy', 'Sell', 'Cover', 'Short'],
            traders: ['Trader 1', 'Trader 2', 'Trader Joe'],
            allocationGridColumns: [
            {
                title: "Portfolio",
                field: "portfolio",
                width: "120px"
            }, {
                field: "prime",
                title: "Prime",
                width: "80px"
            }, {
                title: "Strategy",
                field: "strategy",
                width: "80px"
            }, {
                field: "shares",
                title: "Shares",
                width: "80px"
            }]
        }

        var webAPIHost = settings.webApiEndpointHostname;
        var apiHost = settings.apiEndpointHostname;

        this.getConfigValues = function () {
            return config;
        };

        this.getSchemes = function getSchemes(success, error) {
            return storage.async(webAPIHost + '/WebApiService/api/Schemes',
                function (data) {
                    success(data);
                },
                function (error) {
                    error(error);
                }
            );
        };

        this.getTicketDefaults = function getTicketDefaults (dispName, selectedScheme, success, error) {
            return storage.async(webAPIHost + '/WebApiService/api/TicketDefaults?' + 'DISP_NAME=' + dispName + '&SCHEME=' + selectedScheme,
                function(data) {
                    success(data);
                },  
                function(error) {
                    error(data);
                }
            );  
        }

        this.submitOrder = function submitOrder (glx, locale, order, success, error) {
            return storage.asyncPost(apiHost + 'data/trade.submitorder?feature=ORDERENTRY'
                                      + '&glx=' + glx
                                      + '&locale=' + locale
                                      + '&bbcd=' + order.BBCD.ShortName,
            { data: [order] },
            function (data, status, headers, config) {
                success(data, status, headers, config)
            },
            function (data, status, headers, config) {
                error(data, status, headers, config)
            });
        }


        this.getAllocationData = function getAllocationData (amount, success, error) {
            return storage.async(webAPIHost + '/WebApiService/api/Allocation?' + 'Amount=' + amount,
                function(data, status, headers, config) {
                    success(data);
                }
            );
        };

    };	//end svc


    ticketSvc.$inject = ['storage', 'settings'];

    return ticketSvc;
});