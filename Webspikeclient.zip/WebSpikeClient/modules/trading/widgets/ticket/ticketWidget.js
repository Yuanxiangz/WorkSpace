﻿
define(['angular', 'angularDashboard', 'sortable', 'kendo', 'lodash'],
function (angular, adb, sort, kendoPlaceholder, _) {
	'use strict';
	var ticketWidget = angular.module('webSpike.trading.widget.ticket', ['adf.provider', 'kendo.directives']);

	ticketWidget.config(function (dashboardProvider) {
		dashboardProvider
			.widget('ticketWidget', {
				title: 'Ticket',
				image: 'images/Trading_icon.svg',
				description: 'Order Entry',
				templateUrl: 'modules/trading/widgets/ticket/_ticket-view.html',
				controller: 'ticketWidgetCtrl',
				config: {},
				edit: {}
			});
	});


	if (isElectron) {
		ticketWidget.provider('symbolToTrade', function UnicornLauncherProvider() {
			this.$get = function () { return null; };
		});
	}

	ticketWidget.controller('ticketWidgetCtrl', [
        '$scope',
        'auth',
        'streaming',
        'symbolSvc',
        'accounts',
        'ticketSvc',
        'symbolToTrade',
        'pubsub',
        '$stateParams',
        'settings',
        function (
            $scope,
            auth,
            streaming,
            symbolSvc,
            accounts,
            ticketSvc,
            symbolToTrade,
            pubsub,
            $stateParams,
            settings) {

            var configValues = ticketSvc.getConfigValues();

            $scope.defaultColumns = configValues.columns;
            $scope.orderTypes = configValues.orderTypes;

        	$scope.glx2 = '';

        	if (symbolToTrade) {
        		$scope.symbolToTrade = symbolToTrade;
        	} else if ($stateParams.DISP_NAME) {
        		$scope.symbolToTrade = $stateParams.DISP_NAME;
        	} else {
        		$scope.symbolToTrade = '';
        	}

        	$scope.symbolData = {
        		DISP_NAME: $scope.symbolToTrade
        	};

            $scope.Actions = configValues.actions;
        	$scope.Schemes = [];

        	$scope.order = {
        		DISP_NAME: $stateParams.DISP_NAME || symbolToTrade,
        		BUYORSELL: '',
        		VOLUME: '',
        		DISP_PRICE: '',
        		GOOD_UNTIL: 'Day',
        		SCHEME: null
        	};

        	$scope.accounts = [];

        	$scope.traders = configValues.traders;

        	$scope.allocationGridColumns = configValues.allocationGridColumns;

        	$scope.closeTicket = function () {
        		$scope.$close();
        	};

        	$scope.routes = {};

        	$scope.loadSchemes = function () {
        		ticketSvc.getSchemes(
				function gotSchemes(schemes) {
					$scope.Schemes = schemes;
				},
				function getSchemesFailed(error) {
					console.error(error);
				});
        	};

        	$scope.getQuoteForSymbol = function (symbol) {
        		symbolSvc.getsymboldata('orderentry', $scope.glx2, symbol,
					function success(data) {
						$scope.symbolData = data[0];
						$scope.subscribeToSymbol(symbol);
					}, function error() {
						console.error('getQuoteForSymbol failed in ticketWidget.js');
					});
        	};


        	$scope.subscribeToSymbol = function (symbol) {
        		streaming.subscribe('quote', { symbol: symbol }, function (data) {
        			if (data && data.DISP_NAME) {
        				//console.log(data);
        				var symbol = data.DISP_NAME;
        				if ($scope.symbolData && symbol == $scope.symbolData.DISP_NAME) {
        					var pairs = _.pairs(data);
        					$scope.$apply(function () {
        						_.forEach(pairs, function (val, key) {
        							$scope.symbolData[val[0]] = val[1];
        						});
        					});
        				}
        			}
        		}).then(function (subInfo) {
        			if (subInfo) {
        				//console.log(subInfo);
        			}
        		});
        	};

        	$scope.getData = function () {
        		if ($scope.symbolToTrade) {
        			$scope.getQuoteForSymbol($scope.symbolToTrade);
        		}

        		accounts.getBBCDXPerms().then(function (data) {
        			$scope.accounts = data.bbcd;
        			$scope.order.BBCD = data.bbcd[2];
        			$scope.accounts.forEach(function forEachAccount(account) {
        				$scope.routes[account.AcctId] = [];
        				accounts.getRoutes(account)
	                        .then(function gotRoutes(routes) {
	                        	if (routes.length > 0) {
	                        		$scope.routes[account.AcctId] = routes;
	                        		$scope.order.BBCD = $scope.accounts[2];
	                        		$scope.order.EXIT_VEHICLE = $scope.selectedAccountRoutes()[0];
	                        		$scope.order.ORDER_TYPE = "Limit";
	                        	}
	                        });
        			});
        		});
        	}

        	$scope.applySchemeToOrder = function () {
        		var selectedScheme = $scope.order.SCHEME;
        		ticketSvc.getTicketDefaults($scope.symbolData.DISP_NAME, selectedScheme,
					function success(data) {
						$scope.order = data;
						$scope.order.BBCD = $scope.accounts[2];
						$scope.order.EXIT_VEHICLE = $scope.selectedAccountRoutes()[0];
						$scope.order.ORDER_TYPE = "Limit";
					}, function error(error) {
						console.error('Error retrieving data from the web api');
					}
				);
        	};

        	$scope.buildOrderObject = function (order) {
        		order.EXIT_VEHICLE_FULL = order.EXIT_VEHICLE;
        		order.EXIT_VEHICLE = order.EXIT_VEHICLE_FULL.RouteName;
        		order.EXCHANGE = $scope.symbolData.EXCH_NAME;
        		order.ACCT_TYPE = 1;
        		order.ACCT_TYPE_STR = 'Cash';
        		order.BANK = order.BBCD.Bank;
        		order.BRANCH = order.BBCD.Branch;
        		order.CUSTOMER = order.BBCD.Customer;
        		order.DEPOSIT = order.BBCD.Deposit;
        		order.STYP = 1;
        		order.TO_OPEN_POS = 0;
        		order.BaseCode = 109;
        		order.PRICE_TYPE = order.ORDER_TYPE;
        		order.ORDER_DISP_PRICE = order.DISP_PRICE;

        		if (order.PRICE_TYPE != 'Market') {
        			order.STOP_PRICE = order.ORDER_DISP_PRICE;
        			order.PEG_LIMIT = order.ORDER_DISP_PRICE;
        		}
        	}

        	//for now, this function will add a fake staged order to the blotter. This will be dragged to the Order Commit screen, and executed there.
        	$scope.placeStagedOrder = function () {
        		var today = new Date();
        		var mockOrderForBlotter = {
        			'DISP_NAME': $scope.order.DISP_NAME,
        			'BUYORSELL': $scope.order.BUYORSELL,
        			'VOLUME': $scope.order.VOLUME + '',
        			'ORIGINAL_TRADER_ID': 'ANUCCIO@SBDEMO',
        			'VOLUME_TRADED': '0',
        			'CURRENT_STATUS_FULL': 'READY',
        			'NEWS_DATE': today.toLocaleDateString(),
        			'EXIT_VEHICLE': '',    //this will be chosen when executed 
        			'ORDER_ID': '',
        			'CURRENT_BBCD': $scope.order.BBCD.AcctDesc
        		}
        		pubsub.publish('newlyEnteredStagedOrder', [mockOrderForBlotter]);
        		$scope.closeTicket();
        	}

        	$scope.submitOrder = function submitOrder(buyorsell) {
        		var order = _.cloneDeep($scope.order);
        		$scope.buildOrderObject(order);

        		ticketSvc.submitOrder($scope.glx2, 'rotr_dev_locale', order,
					function submitOrderResponseSuccessCallback(data, status, headers, config) {
						pubsub.publish('newlyEnteredTrade', [order.BBCD]);
						$scope.closeTicket();
					},
					function submitOrderResponseErrorCallback(data, status, headers, config) {
						console.log(data);
						$scope.closeTicket();
					}
				);

        	};

        	$scope.selectedAccountRoutes = function selectedAccountRoutes() {
        		if (typeof $scope.order.BBCD == 'undefined') {
        			return [];
        		}
        		return $scope.routes[$scope.order.BBCD.AcctId];
        	};

        	$scope.showPriceInput = function showPriceInput() {
        		if (!$scope.order) { return false; }
        		switch ($scope.order.ORDER_TYPE) {
        			case 'Limit': return true;
        			case 'Market': return false;
        			default: return false;
        		}
        	};

        	$scope.priceInputLabel = function priceInputLabel() {
        		if (!$scope.order) return null;
        	};

        	$scope.showAllocations = false;
        	$scope.toggleShowAllocations = function () {
        		$scope.showAllocations = !$scope.showAllocations;
        	};

        	//Run allcoations when user changes the quantity
        	var allocationData = { data: [] };
        	$scope.getAllocationData = function () {
        		if (!$scope.order.VOLUME) {
        			$scope.order.VOLUME = 0;
        		}
        		ticketSvc.getAllocationData($scope.order.VOLUME,
					  function (data) {

					  	allocationData.data = data;

					  	//refresh datasource
					  	$scope.allocations = new kendo.data.DataSource(allocationData);
					  });
        	};

        	$scope.allocations = new kendo.data.DataSource(allocationData);

        	$scope.onSelection = function (selected) {
        		var selectedUid = selected.selected.uid;
        		var dataSource = $scope.allocPie.dataSource;
        		var data = dataSource.data();

        		// reset all existing "explode" settings
        		for (var i = 0; i < data.length; i++) {
        			data[i].explode = false;
        		}

        		// find the unique data item and explode that slice
        		var dataItem = dataSource.getByUid(selectedUid);
        		dataItem.explode = true;
        		$scope.allocPie.refresh();
        	};

        	$scope.onSeriesClick = function (e) {
        		var dataItemUid = e.dataItem.uid;
        		// find the HTML element based on the uid attribute
        		var row = $scope.allocGrid.table.find("[data-uid=" + dataItemUid + "]");
				$scope.allocGrid.select(row);
        	};

        	$scope.init = function init() {
        		$scope.loadSchemes();
        		$scope.symbolData = null;
        		auth.getGlxToken()
				.then(function gotGlxToken(glx) {
					streaming.init()
					.then(function () {
						$scope.glx2 = glx;
						$scope.getData();
					});
				});
        	};

        	$scope.init();

        }]);

	ticketWidget.filter('buyorsell', function () {
		return function (input) {
			var retString = input;
			if (input.toUpperCase() === 'SELLSHORT') {
				retString = 'SHORT';
			}
			return retString;
		}
	});

	return ticketWidget;
});

