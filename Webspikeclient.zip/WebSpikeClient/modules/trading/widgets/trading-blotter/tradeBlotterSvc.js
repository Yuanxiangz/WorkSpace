define([], function() {
	'use strict';

	var tradeBlotterSvc = function ($q, storage, settings) {
		var rootURL = settings.apiEndpointHostname;
		var defaultValues = {
		    bbcd: 'TAL;TEST;ANUCCIO;TRADING',
			columns: ['DISP_NAME', 'BUYORSELL', 'VOLUME', 'ORIGINAL_TRADER_ID', 'VOLUME_TRADED', 'CURRENT_STATUS_FULL', 'NEWS_DATE', 'EXIT_VEHICLE', 'ORDER_ID'],
			locale: 'rotr_dev_locale'
		}

		this.getDefaultValues = function () {
			return defaultValues;
		}

		this.getOrders = function (glx, columns, locale, bbcd, order_id) {
			var deferred = $q.defer();
			var orderCommand = (order_id) ? 'trade.orderevents' : 'trade.orders';
			
			var getOrdersURL = rootURL
				+ 'data/' + orderCommand + '?feature=ORDERS'
	            + '&glx=' + glx
	            + '&columns=' + encodeURIComponent(columns)
	            + '&locale=' + locale
	            + '&bbcd=' + bbcd;

	        if (order_id)
	        	getOrdersURL += '&order_id=' + order_id;

	        storage.async(getOrdersURL,
				function(data) {
					deferred.resolve(data);
				},
				function (data, status, headers, config) {
					deferred.reject(status);
				}
			);

	        return deferred.promise;
		}

	};	//end svc


	tradeBlotterSvc.$inject = ['$q', 'storage', 'settings'];

	return tradeBlotterSvc;
});