﻿define(['angular', 'lodash', 'angularDashboard', 'sortable', 'kendo', 'jquery'], 
    function (angular, _, adb,sort) {
        'use strict';

        var tradeBlotterWidget = angular.module('webSpike.trading.widget.tradeBlotter', ['adf.provider', 'kendo.directives']);
       
        tradeBlotterWidget.config(function (dashboardProvider) {
            dashboardProvider
                .widget('tradeBlotterWidget', {
                    title: 'Trade Blotter',			    
                    description: 'Trade Blotter',
                    templateUrl: 'modules/trading/widgets/trading-blotter/_trade-blotter-view.html',
                    controller: 'TradeBlotterWidgetCtrl',
                    config: {
                    },
                    edit: {	}
                });
        });

        tradeBlotterWidget.controller('TradeBlotterWidgetCtrl', ['$scope', 'settings', 'auth', '$http','$q', 'streaming', 'storage', 'pubsub', 'watchlistSvc', 'tradeBlotterSvc',
            function ($scope, settings, auth, $http, $q, streaming, storage, pubsub, watchlistSvc, tradeBlotterSvc) {
                 $scope.bbcds = [];
                 $scope.orderDefaultValues = tradeBlotterSvc.getDefaultValues();
                 $scope.columns = $scope.orderDefaultValues.columns;
                 $scope.settings = null;
                 $scope.orderBlotterColumns = [];
                 $scope.gridInitialized = false;
                 $scope.orders = [];
                 $scope.glxToken = '';
                 $scope.config = {
                    pubsubNewlyEnteredTradeHandle: null,
                    pubsubNewlyEnteredStagedOrderHandle: null
                 }

                 $scope.showAjaxLoading = false;
                
                $scope.getFields = function getFields() {
                    var deferred = $q.defer();

                    watchlistSvc.getFields($scope.glxToken).then(
                        function(data) {
                            if (data.Data && data.Data.symlist) {
                                var symData = data.Data.orders;
                                $scope.setGridColumns(symData);
                                deferred.resolve('success');
                            } else {
                                deferred.resolve('noresults');
                            }                            
                        }, function (error) {
                            console.log(error);
                            deferred.resolve('error');
                        }
                    );
                    
                    return deferred.promise;
                };

                //right now this is using kendo grid. Subject to change
                $scope.setGridColumns = function (symData) {
                    for (var field in symData) {
                        var curr = symData[field];
                        var indx = $scope.columns.indexOf(curr.Name);
                        if (indx > -1) {    //only show column if it was requested
                            var currObj = {
                                'field': curr['Name'],
                                'title': curr['Display'],
                                'headerAttributes': {
                                    style: 'text-align:center; font-size:13px; white-space: nowrap; font-weight: bold;'
                                },
                                'attributes': {
                                	style: 'text-align:center; font-size:13px; white-space: nowrap;'
                                }
                            };
                            switch(curr.Name) {
                                case 'BUYORSELL': {
                                    currObj.template = function (dataItem) {
                                    var htmlTemplate = '';
                                    if (dataItem.BUYORSELL) {
                                        switch (dataItem.BUYORSELL.toLowerCase()) {
                                            case 'buy': {
                                                htmlTemplate = '<span class="kendo-buyorsell-label label label-success">BUY</span>';
                                                break;
                                            }
                                            case 'sell': {
                                                htmlTemplate = '<span class="kendo-buyorsell-label label label-danger">SELL</span>';
                                                break;
                                            }
                                            case 'sellshort': {
                                                htmlTemplate = '<span class="kendo-buyorsell-label label label-warning">SHORT</span>';
                                                break;
                                            }
                                            case 'cover': {
                                                htmlTemplate = '<span class="kendo-buyorsell-label label label-cover">COVER</span>';
                                                break;
                                            }
                                        }
                                    }
                                    return htmlTemplate;
                                 }
                                    break;
                                }
                                case 'ORDER_ID': {
                                    currObj.template = function (dataItem) {
                                        return '<span class="order-id-cell">' + dataItem.ORDER_ID  + '</span>';     //this is so we can grab the order id name easily on row select 
                                    }
                                    break;
                                }
                                case 'VOLUME': {
                                    currObj.template = function (dataItem) {
                                        return '<span class="volume-cell">' + dataItem.VOLUME  + '</span>';     //this is so we can grab the order id name easily on row select 
                                    }
                                    break;
                                }
                                case 'DISP_NAME': {
                                    currObj.template = function (dataItem) {
                                        return '<span class="disp-name-cell">' + dataItem.DISP_NAME  + '</span>';     //this is so we can grab the order id name easily on row select 
                                    }
                                    break;
                                }
                            }   //end switch

                            $scope.orderBlotterColumns[indx]= currObj;  //push to columns array for kendo grid
                        }
                    }
                };

                $scope.addStagedOrderToBlotter = function(stagedOrder) {
                    if (!$scope.showAjaxLoading) {  //this makes sure that a cached order isn't loaded on controller init
                        $scope.orders.push(stagedOrder); //this triggers ezeGrid to update
                    }
                };

                $scope.getData = function (bbcd) {
                    $scope.getFields().then(function (msg) {
                        if (msg === 'success') {
                            $scope.showAjaxLoading = true;
                            $scope.getOrders();
                        }
                    });                
                };

                $scope.getOrders = function () {
                    tradeBlotterSvc.getOrders($scope.glxToken, $scope.orderDefaultValues.columns.join(','), $scope.orderDefaultValues.locale, $scope.orderDefaultValues.bbcd)
                        .then(
                            function(data) {
                                if (data.Data) {
                                    $scope.orders = data.Data;                                                                       
                                } else {
                                    console.log('no data returned from GetOrders');
                                }
                                $scope.showAjaxLoading = false;
                            },
                            function(errorStatus) {
                                console.log(errorStatus);
                                $scope.showAjaxLoading = false;
                            }
                    );
                };

                //grab the order object of the row that was clicked
                $scope.onSymbolSelect = function(orderid) {                    
                    var currOrderObj = _.filter($scope.orders, function(order) {
                        return order["ORDER_ID"] === orderid;
                    });
                    var jsonOrderObj = JSON.stringify(currOrderObj);
                    pubsub.publish($scope.settings.tradeblotter.symbolselected, [jsonOrderObj]);     //adds to session storage
                };

                $scope.final = function () {
                    pubsub.unsubscribe($scope.config.pubsubNewlyEnteredTradeHandle);
                    pubsub.unsubscribe($scope.config.pubsubNewlyEnteredStagedOrderHandle);
                };

                $scope.init = function () {
                    $scope.settings = settings.getSettingsKeys;
                    $scope.$on('$destroy', $scope.final);
                    $scope.showAjaxLoading = true;
                    auth.getGlxToken().then(function (result) {
                        if (result && result !== 'error') {
                            $scope.glxToken = result;
                            $scope.config.pubsubNewlyEnteredTradeHandle =
                                pubsub.subscribe('newlyEnteredTrade', $scope.getData);
                            $scope.config.pubsubNewlyEnteredStagedOrderHandle =
                                pubsub.subscribe('newlyEnteredStagedOrder', $scope.addStagedOrderToBlotter);
                            $scope.getData();
                        }
                    });

                };

                $scope.init();

            }]);

    return tradeBlotterWidget;

});