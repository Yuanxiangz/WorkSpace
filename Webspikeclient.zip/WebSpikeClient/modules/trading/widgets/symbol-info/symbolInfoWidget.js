'use strict';

define(['angular', 'angularDashboard'],
function (angular,adb) {
	var symbolInfoWidget = angular.module('webSpike.trading.widget.symbolinfo', ['adf.provider']);

	symbolInfoWidget.config(function (dashboardProvider) {
		dashboardProvider
			.widget('symbolInfoWidget', {
			    title: 'Symbol',
				description: 'Information on Symbol',
				templateUrl: 'modules/trading/widgets/symbol-info/_symbol-info-view.html',
				controller: 'symbolInfoWidgetController'
			});
	});

	symbolInfoWidget.controller('symbolInfoWidgetController', ['$scope', 'pubsub', 'settings', 'watchlistSvc', 'auth', 
        function ($scope, pubsub, settings, watchlistSvc, auth) {

        $scope.settings = null;
        $scope.pubsubHandle = {
            symbolClicked: null
        };
        $scope.glxToken = '';
        $scope.currentSymbol = {
        	symboldata: null
        };

        $scope.setSymbol = function (sym) {
            var orderObj = JSON.parse(sym)[0];
            var dispName = orderObj.DISP_NAME;
            watchlistSvc.getSymbolInfo($scope.glxToken, dispName)
            	.then(function(result) {
            		$scope.currentSymbol.symboldata = result[0];
            	}, function(errorStatus) {
            		console.log('error getting symbol info: ' + errorStatus);
            	});
            
        };
	    $scope.final = function () {
	        pubsub.unsubscribe($scope.pubsubHandle.symbolClicked);      //unsubscribe on $destroy
	    };

	    $scope.init = function () {
	        auth.getGlxToken().then(function (result) {		//first get the glx2 token
                if (result && result !== 'error') {
                    $scope.glxToken = result;
                    $scope.settings = settings.getSettingsKeys;
			        $scope.pubsubHandle.symbolClicked = pubsub.subscribe($scope.settings.tradeblotter.symbolselected, $scope.setSymbol);    //set up a listener for user clicks to the chart
			        $scope.$on('$destroy', $scope.final);
                }
            });
	    };

	    $scope.init();


	}]);

	return symbolInfoWidget;
});

