﻿
define(['angular',
    './watchlist/watchlistSvc',
    './trading-blotter/tradeBlotterSvc',
    './ticket/ticketSvc',
    './chart/chartSvc',
    './highchart/highchartSvc',
    './trading-home/tradingHomeWidget',
    './market-overview/marketOverview',
    './watchlist/watchlistWidget',
    './brokers-fills/brokersFillsWidget',
    './trading-blotter/tradeBlotterWidget',
    './trading-heatmap/tradingHeatmapWidget',
    './trading-workflows/tradingWorkflowsWidget',
    './symbol-info/symbolInfoWidget',
    './ticket/ticketWidget',
    './level2/level2Widget',
    './chart/chartWidget',
    './highChart/chartWidget'],
function (angular,
    watchlistSvc,
    tradeBlotterSvc,
    ticketSvc,
    chartSvc,
    highchartSvc,
    tradingHomeWidget,
    marketOverviewWidget,
    watchlistWidget,
    brokerFills,
    tradeBlotter,
    tradingHeatMap,
    tradingWorkflows,
    symbolInfoWidget,
    ticketWidget,
    level2Widget,
    chartWidget,
    highChartWidget) {
    'use strict';

    var tradingWidgets = angular.module("webSpike.trade.widgets", [tradingHomeWidget.name,
        marketOverviewWidget.name,
		watchlistWidget.name,
        brokerFills.name,
        tradeBlotter.name,
        tradingHeatMap.name,
        tradingWorkflows.name,
        symbolInfoWidget.name,
        ticketWidget.name,
        level2Widget.name,
        chartWidget.name,
        highChartWidget.name
    ]);

	tradingWidgets.service('watchlistSvc', watchlistSvc);
	tradingWidgets.service('tradeBlotterSvc', tradeBlotterSvc);
	tradingWidgets.service('ticketSvc', ticketSvc);
	tradingWidgets.service('chartSvc', chartSvc);
	tradingWidgets.service('highchartSvc', highchartSvc);

	return tradingWidgets;
});