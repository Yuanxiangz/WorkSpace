﻿define(['angular', 'angularDashboard', 'sortable', 'kendo', 'jquery'],
    function (angular,adb,sort) {
        'use strict';

        var brokersFillsWidget = angular.module('webSpike.trading.widget.brokersFills', ['adf.provider', 'kendo.directives']);

        brokersFillsWidget.config(function (dashboardProvider) {
            dashboardProvider
                .widget('brokersFillsWidget', {
                    title: 'Brokers & Fills',
                    description: 'Brokers & Fills',
                    templateUrl: 'modules/trading/widgets/brokers-fills/_brokers-fills-view.html',
                    controller: 'BrokersFillsWidgetCtrl',
                    config: {
                    },
                    edit: {	}
                });
        });

        brokersFillsWidget.controller('BrokersFillsWidgetCtrl', ['$scope', 'pubsub', 'settings',
            function ($scope, pubsub, settings) {

                $scope.settings = null;
                $scope.pubsubHandle = {
                    symbolClicked: null
                };

                $scope.currentOrder = {};
                $scope.fillPercentage = 0;

                $scope.setSymbol = function (sym) {
                    var orderObj = JSON.parse(sym)[0];

                    $scope.currentOrder.BUYORSELL = orderObj.BUYORSELL.toUpperCase();
                    $scope.currentOrder.DISP_NAME = orderObj.DISP_NAME;
                    $scope.currentOrder.ORIGINAL_TRADER_ID = orderObj.ORIGINAL_TRADER_ID.split('@')[0];  //take off @<domain> for now
                    $scope.currentOrder.VOLUME = orderObj.VOLUME;
                    $scope.currentOrder.NEWS_DATE = orderObj.NEWS_DATE;
                    $scope.currentOrder.VOLUME_TRADED = orderObj.VOLUME_TRADED;

                    $scope.fillPercentage = (eval(orderObj.VOLUME_TRADED.replace(/\,/g, ''))/(eval(orderObj.VOLUME.replace(/\,/g, '')))*100);

                    $(".fillpct").kendoSparkline({
                        type: "bullet",
                        data: $scope.fillPercentage,
                        valueAxis: {
                            min: 0,
                            max: 100,
                            plotBands: [{
                                    from: 0, to: 100, color: "#787878", opacity: 0.20
                                }]
                        }
                    });
                };

                $scope.final = function () {
                    pubsub.unsubscribe($scope.pubsubHandle.symbolClicked);      //unsubscribe on $destroy
                };

                $scope.init = function () {
                    $scope.settings = settings.getSettingsKeys;
                    $scope.pubsubHandle.symbolClicked = pubsub.subscribe($scope.settings.tradeblotter.symbolselected, $scope.setSymbol);    //set up a listener for user clicks to the chart

                    $scope.$on('$destroy', $scope.final);

                };

                $scope.init();

            }]);

        return brokersFillsWidget;

});
