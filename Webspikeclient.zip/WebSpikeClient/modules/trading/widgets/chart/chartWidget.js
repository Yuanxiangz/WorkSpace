﻿
define(['angular', 'angularDashboard', 'sortable', 'kendo', 'jquery', 'lodash', 'moment', '../market-overview/marketDataApiHelper'],
  function(angular, adb, sort, kendoPlaceholder, $, _, moment, MarketDataHelper) {
    'use strict';
    var chartWidget = angular.module('webSpike.trading.widget.chart', ['adf.provider', 'kendo.directives']);

    chartWidget.config(function(dashboardProvider) {
      dashboardProvider
        .widget('chartWidget', {
          title: 'Chart',
          image: 'images/Trading_icon.svg',
          description: 'Chart',
          templateUrl: 'modules/trading/widgets/chart/_chart-view.html',
          controller: 'chartWidgetCtrl',
          config: {},
          edit: {}
        });
    });

    chartWidget.controller('chartWidgetCtrl', [
      '$scope',
      '$http',
      '$q',
      'auth',
      'settings',
      'streaming',
      'storage',
      'symbolSvc',
      'watchlistSvc',
      'accounts',
      'ticketSvc',
      'pubsub',
      'chartSvc',
      function(
        $scope,
        $http,
        $q,
        auth,
        settings,
        streaming,
        storage,
        symbolSvc,
        watchlistSvc,
        accounts,
        ticketSvc,
        pubsub,
        chartSvc) {

        var marketDataHelperObj = new MarketDataHelper(settings.apiEndpointHostname);

        $scope.defaultColumns = ['DISP_NAME', 'TRDPRC_1', 'CHANGE_LAST', 'TRDPRC_2', 'ACVOL_1', 'SYMBOL_DESC'];
        $scope.chartTypes = [
          'intraday'
        ];

        $scope.startDate = new Date();
        $scope.endDate = new Date();

        $scope.defaultSymbols = ['FB', 'BAC'];

        $scope.symbols = [];

        $scope.series = [];
        $scope.valueAxes = [];
        $scope.navigatorSeries = [];
        $scope.emaSeries = [];

        $scope.chartData = [];

        var possibleColors = ['#3984C5', '#FF4747', '#00B09B', '#F18B29'];

        $scope.symbolColors = {};

        for (var i = 0; i < $scope.symbols.length; i++) {
          $scope.symbolColors[$scope.symbols[i]] = possibleColors[i];
        }

        $scope.glx2 = '';
        $scope.apiHost = settings.apiEndpointHostname;
        $scope.webApiHost = settings.webApiEndpointHostname;

        $scope.getMin = function getMin(collection, property) {
          return _.min(collection, function(datapoint) {
            return datapoint[property];
          })[property];
        };

        $scope.getMax = function getMin(collection, property) {
          return _.max(collection, function(datapoint) {
            return datapoint[property];
          })[property];
        };

        $scope.minMultiplier = 0.9999;
        $scope.maxMultiplier = 1.0001;

        $scope.tooltip = {
          visible: true,
          template: '#= dataItem.DISP_NAME # <br />' /
            +'#= kendo.format(\'{0:MM/dd/yyyy}\',dataItem.TRD_DATE) #' /
            +'#= dataItem.TRDTIM_1 ? dataItem.TRDTIM_1 : \'\' # <br />' /
            +'High:   #= dataItem.HIGH_1 # <br />' /
            +'Low:    #= dataItem.LOW_1 # <br />' /
            +'Open:   #= dataItem.OPEN_PRC # <br />' /
            +'Close:  #= dataItem.SETTLE # <br />' /
            +'Volume: #= dataItem.ACVOL_1 #',
          background: '#DAF8F8',
          border: {
            color: '#DAF8F8'
          }
        };

        $scope.otherAxes = {
          visible: false,
          minorGridLines: {
            visible: false
          },
          majorGridLines: {
            visible: false
          },
          baseUnit: 'fit',
          maxDateGroups: 50,
          axisCrossingValues: [0, Math.floor(Number.MAX_VALUE), 0, Math.floor(Number.MAX_VALUE), 0]
        };

        $scope.navigatorCategoryAxis = {
          maxDateGroups: 150,
          baseUnit: 'fit',
          labels: {
            step: 1
          },
          max: moment()
        };

        $scope.init = function() {
          auth.getGlxToken()
            .then(function(glx2) {
              $scope.glx2 = glx2;
              $scope.initChart();
            });
        };

        $scope.initChart = function() {
          var queryUrl = marketDataHelperObj.intradayDataUri($scope.defaultSymbols, $scope.glx2, 1);
          storage.async(queryUrl,
            function success(data) {
              _.forEach(data.Data, function(dataSym) {
                $scope.processChartData(dataSym);
              });
              $scope.createChart();
            },
            function failure(data) {
              console.error(data);
            });
        };

        $scope.processChartData = function(data) {
          var seriesData = _(data)
            .map(function transformAllData(datapoint) {
              var newDataPoint = {};

              newDataPoint.DISP_NAME = datapoint.DISP_NAME;
              newDataPoint.HIGH_1 = datapoint.HIGH_1;
              newDataPoint.LOW_1 = datapoint.LOW_1;
              newDataPoint.OPEN_PRC = datapoint.OPEN_PRC;
              newDataPoint.SETTLE = datapoint.SETTLE;
              newDataPoint.CHART_DATE = moment(datapoint.CHART_DATE).add(5, 'h');
              newDataPoint.TRDTIM_1 = datapoint.TRDTIM_1;
              newDataPoint.ACVOL_1 = datapoint.ACVOL_1;
              return newDataPoint;
            })
            .filter(function filterNoVolumeTicks(dataPoint) {
              return dataPoint.ACVOL_1 !== 0;
            })
            .value();

          $scope.chartData.push(seriesData);

          var symbol = seriesData[0].DISP_NAME;
          $scope.symbols.push(symbol);

          var color = possibleColors[$scope.series.length / 2];
          $scope.symbolColors[symbol] = color;

          var seriesConstruct = {};
          seriesConstruct.data = seriesData;
          seriesConstruct.axis = symbol;
          seriesConstruct.tooltip = $scope.tooltip;
          seriesConstruct.color = color;
          seriesConstruct.downColor = '#D14B4C';
          seriesConstruct.openField = 'OPEN_PRC';
          seriesConstruct.highField = 'HIGH_1';
          seriesConstruct.lowField = 'LOW_1';
          seriesConstruct.closeField = 'SETTLE';
          seriesConstruct.type = 'ohlc';

          $scope.series.push(seriesConstruct);


          var valueAxis = {};
          valueAxis.name = symbol;
          valueAxis.min = $scope.getMin(seriesData, 'LOW_1') * $scope.minMultiplier;
          valueAxis.max = $scope.getMax(seriesData, 'HIGH_1') * $scope.maxMultiplier;
          valueAxis.visible = true;
          valueAxis.minorGridLines = {
            visible: false
          };
          valueAxis.majorGridLines = {
            visible: true
          };
          valueAxis.color = color;

          $scope.valueAxes.push(valueAxis);


          var navigatorSeries = {};
          navigatorSeries.type = 'area';
          navigatorSeries.data = seriesData;
          navigatorSeries.axis = symbol;
          navigatorSeries.color = color;
          navigatorSeries.field = 'ACVOL_1';
          navigatorSeries.categoryField = 'CHART_DATE';
          navigatorSeries.tooltip = {
            visible: false
          };

          $scope.navigatorSeries.push(navigatorSeries);


          var emaData = {};
          emaData.data = chartSvc.calculateEMA(seriesData, 'SETTLE');
          emaData.axis = symbol;
          emaData.type = 'line';
          emaData.field = 'EMA';
          emaData.style = 'smooth';
          emaData.width = 3;
          emaData.opacity = 0.5;
          emaData.markers = {
            visible: false
          };
          emaData.color = color;
          emaData.tooltip = {
            visible: false
          };

          $scope.series.push(emaData);
        };

        $scope.createChart = function() {
          $('#tr-chart').kendoStockChart({
            legend: {
              visible: true
            },
            dateField: 'CHART_DATE',
            series: $scope.series,
            valueAxes: $scope.valueAxes,
            navigator: {
              series: $scope.navigatorSeries,
              categoryAxis: $scope.navigatorCategoryAxis
            },
            categoryAxis: $scope.otherAxes
          });

          $scope.stockChart = $('#tr-chart').data('kendoStockChart');
        };

        $scope.addSymbolToChart = function addSymbolToChart(symbol) {
          if ($scope.symbols.length === 4) {
            $scope.errorMessage = 'Maximum of 4 symbols allowed on chart. Could not add symbol';
          } else {
            var queryUrl = marketDataHelperObj.intradayDataUri(symbol, $scope.glx2, 1);
            storage.async(queryUrl,
              function success(data) {
                $scope.processChartData(data.Data[0]);
                $scope.stockChart.refresh();
                //$scope.createChart();
              },
              function failure(data) {
                console.error(data);
              });
          }
        };

        $scope.removeSymbolFromChart = function removeSymbolFromChart(symbolToRemove) {
          _.remove($scope.series, function(series) {
            return series.axis === symbolToRemove;
          });

          _.remove($scope.symbols, function(symbol) {
            return symbol === symbolToRemove;
          });

          _.remove($scope.valueAxes, function(axis) {
            return axis.name === symbolToRemove;
          });

          _.remove($scope.navigatorSeries, function(series) {
            return series.axis === symbolToRemove;
          });

          $scope.createChart();
        };

        $scope.init();
      }
    ]);

    return chartWidget;
  });
