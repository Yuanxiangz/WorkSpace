﻿'use strict';

define(['angular', 'angularDashboard', 'sortable', 'kendo', 'jquery'],
function (angular, adb, sort) {
    var widget = angular.module('webSpike.trading.widget.workflows', []);
    
    widget.config(function (dashboardProvider) {
        dashboardProvider
			.widget('tradingWorkflowsWidget', {
			    title: 'Trade Workflows',
			    description: 'A collection of common trading workflows.',
			    templateUrl: 'modules/trading/widgets/trading-workflows/_trading-workflows-view.html',
			    controller: 'TradingWorkflowsWidgetCtrl',
			    config: {
			    },
			    edit: {}
			});
    });

    widget.controller('TradingWorkflowsWidgetCtrl', ['$scope', function ($scope) {

    	$scope.workflows = [
		    {
			    title: "Add new equity trade",
			    description: "This is a trade template to input an equity trade with basic setup.",
				state: "trading.blotter"
		    },
			{
				title: "Add new options trade",
				description: "This is a trade template to input an options trade with basic setup.",
				state: "trading.blotter"
			},
			{
				title: "Add new FX trade",
				description: "This is a trade template to input an FX trade with basic setup.",
				state: "home"
			},
			{
				title: "Add new fixed income trade",
				description: "This is a trade template to input an fixed income trade with basic setup.",
				state: "trading"
			},
			{
				title: "Buy US Equity",
				description: "This is a trade template to input a US based equity trade with basic setup.",
				state: "trading"
			},
			{
				title: "Sell US Equity",
				description: "This is a trade template to input a sell order for a US based equity trade with basic setup.",
				state: "trading"
			},
			{
				title: "Buy 1,000 AAPL",
				description: "This is a trade template to buy an order of quantity 1,000 for Apple Inc. (AAPL) equity with default brokers.",
				state: "trading"
			},
			{
				title: "Short 1,000 MSFT",
				description: "This is a trade template to input a sell order of quantity 1,000 for Microsoft (MSFT) equity with default brokers.",
				state: "trading"
			},
			{
				title: "Cancel all open orders",
				description: "This workflow will automatically cancel all open orders.  Authorization will be required.",
				state: "trading"
			}
	    ];

    }]);

    return widget;
});