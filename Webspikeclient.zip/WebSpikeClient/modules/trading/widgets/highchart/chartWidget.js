﻿
define([
        'angular',
        'angularDashboard',
        'sortable',
        'kendo',
        'jquery',
        'lodash',
        'moment',
        '../market-overview/marketDataApiHelper',
        'highcharts'
    ],
    function(angular,
        adb,
        sort,
        kendoPlaceholder,
        $,
        _,
        moment,
        marketDataHelper,
        highcharts) {
        'use strict';
        var chartWidget = angular.module('webSpike.trading.widget.highchart', ['adf.provider', 'kendo.directives']);

        chartWidget.config(function(dashboardProvider) {
            dashboardProvider
                .widget('highchartWidget', {
                    title: 'HighChart',
                    image: 'images/Trading_icon.svg',
                    description: 'Chart using Highchart',
                    templateUrl: 'modules/trading/widgets/highChart/_chart-view.html',
                    controller: 'highchartWidgetCtrl',
                    config: {},
                    edit: {}
                });
        });

        chartWidget.controller('highchartWidgetCtrl', [
            '$scope',
            '$http',
            '$q',
            'auth',
            'settings',
            'streaming',
            'storage',
            'highchartSvc',
            'pubsub',
            '$stateParams',
            function(
                $scope,
                $http,
                $q,
                auth,
                settings,
                streaming,
                storage,
                highchartSvc,
                pubsub,
                $stateParams) {



                var marketDataHelperObj = new marketDataHelper(settings.apiEndpointHostname);

                $scope.defaultColumns = ['DISP_NAME', 'TRDPRC_1', 'CHANGE_LAST', 'TRDPRC_2', 'ACVOL_1', 'SYMBOL_DESC'];
                $scope.chartTypes = [
                    'intraday'
                ];

                $scope.startDate = new Date();
                $scope.endDate = new Date();

                $scope.defaultSymbols = ['FB'];

                $scope.symbols = [];


                $scope.series = [];
                $scope.emaSeries = [];

                $scope.chartData = [];

                $scope.plotOptions = {};

                $scope.errorMesssage = null;

                var possibleColors = ['#3984C5', '#FF4747', '#00B09B', '#F18B29'];

                $scope.symbolColors = {};

                for (var i = 0; i < $scope.symbols.length; i++) {
                    $scope.symbolColors[$scope.symbols[i]] = possibleColors[i];
                }

                $scope.rangeButtons = [
                    {
                        type: 'day',
                        count: 1,
                        text: '1d'
                    },
                    {
                        type: 'day',
                        count: 3,
                        text: '3d'
                    },
                    {
                        type: 'week',
                        count: 1,
                        text: '1w'
                    },
                    {
                        type: 'month',
                        count: 1,
                        text: '1m'
                    },
                    {
                        type: 'month',
                        count: 3,
                        text: '3m'
                    },
                    {
                        type: 'year',
                        count: 1,
                        text: 'YTD'
                    },
                    {
                        type: 'year',
                        count: 5,
                        text: '5y'
                    },
                    {
                        type: 'year',
                        count: 10,
                        text: '10y'
                    }
                ];

                $scope.glx2 = '';
                $scope.apiHost = settings.apiEndpointHostname;
                $scope.webApiHost = settings.webApiEndpointHostname;

                $scope.initChart = function (symbols) {
                    if ($scope.chart) {
                        $scope.tearDown();
                        $scope.chart.destroy();
                    }
                    symbols = symbols || $scope.defaultSymbols;
                    var queryUrl = marketDataHelperObj.intradayDataUri(symbols, $scope.glx2, 1);
                    storage.async(queryUrl,
                        function success(data) {
                            _.forEach(data.Data, function(dataSym) {
                                $scope.processChartData(dataSym, false);
                            });
                            $scope.createChart();
                        },
                        function failure(data) {
                            console.error(data);
                        });
                };

                $scope.processChartData = function (data, multiple) {
                    
                    var groupingUnits = [
                        [
                            'minute', // unit name
                            [5, 10, 15] // allowed multiples
                        ], [
                            'hour',
                            [1, 3, 6, 12]
                        ], [
                            'day',
                            [1, 3, 5, 10]
                        ], [
                            'month',
                            [1, 3, 6, 12]
                        ]
                    ];

                    if (multiple !== true) {
                        $scope.chartType = 'ohlc';
                    } else {
                        $scope.chartType = 'line';
                    }


                    var seriesData = _(data)
                        .map(function transformAllData(datapoint) {
                            var newDataPoint = {};

                            newDataPoint.DISP_NAME = datapoint.DISP_NAME;
                            newDataPoint.high = datapoint.HIGH_1;
                            newDataPoint.low = datapoint.LOW_1;
                            newDataPoint.open = datapoint.OPEN_PRC;
                            newDataPoint.close = datapoint.SETTLE;
                            newDataPoint.x = moment(datapoint.CHART_DATE).toDate();
                            if (multiple !== true) {
                                newDataPoint.y = datapoint.ACVOL_1;
                                //newDataPoint.y = datapoint.SETTLE;
                            } else {
                                newDataPoint.y = datapoint.SETTLE;
                            }
                            
                            newDataPoint.TRDTIM_1 = datapoint.TRDTIM_1;
                            newDataPoint.ACVOL_1 = datapoint.ACVOL_1;
                            return newDataPoint;
                        })
                        .filter(function filterNoVolumeTicks(dataPoint) {
                            return dataPoint.ACVOL_1 !== 0;
                        })
                        .value();


                    $scope.chartData.push(seriesData);

                    var symbol = seriesData[0].DISP_NAME;
                    $scope.symbols.push(symbol);
                    var color;

                    if (multiple !== true) {
                        color = possibleColors[$scope.series.length / 2];
                        $scope.symbolColors[symbol] = color;
                    } else {
                        color = possibleColors[$scope.series.length];
                        $scope.symbolColors[symbol] = color;
                    }


                    var seriesConstruct = {};
                    seriesConstruct.name = symbol;
                    seriesConstruct.data = seriesData;
                    if (multiple !== true) {
                        seriesConstruct.type = 'candlestick';
                    } else {
                        seriesConstruct.type = 'line';
                    }
                    seriesConstruct.color = color;
                    seriesConstruct.pointInterval = 5 * 60 * 1000;
                    seriesConstruct.dataGrouping = {
                        units: groupingUnits
                    };

                    $scope.series.push(seriesConstruct);

                    if (multiple !== true) {
                        var volumeSeries = {};
                        volumeSeries.type = 'column';
                        volumeSeries.name = symbol + ' - Volume';
                        volumeSeries.data = seriesData;
                        volumeSeries.color = color;
                        volumeSeries.yAxis = 1;
                        volumeSeries.dataGrouping = {
                            units: groupingUnits
                        };
                        $scope.series.push(volumeSeries);

                        var emaData = {};
                        emaData.data = highchartSvc.calculateEMA(seriesData, 'close');
                        emaData.type = 'line';
                        emaData.color = color;
                        emaData.name = symbol + ' - EMA';
                        emaData.dataGrouping = {
                            units: groupingUnits
                        };
                        $scope.plotOptions = {};
                        $scope.series.push(emaData);
                    } else {
                        $scope.plotOptions.series = $scope.plotOptions.series || {};
                        $scope.plotOptions.series.compare = 'percent';
                    }

                };

                var afterSetExtremes = function(e) {
                //    var queryUrl = marketDataHelperObj.getChartDataQuery($scope.symbols, moment(e.min).format("MM/DD/YYYY"), moment(e.max).format("MM/DD/YYYY"), $scope.glx2, )
                };

                $scope.createChart = function () {
                    $scope.chart = new highcharts.StockChart({
                        chart: {
                            renderTo: 'tr-chart',
                            marginRight: 10,
                            events: {
                                load: function() {

                                },
                                afterSetExtremes: afterSetExtremes
                            }
                        },

                        title: {
                            text: $scope.symbols.join(',')
                        },
                        yAxis: [
                            {
                                labels: {
                                    align: 'right',
                                    x: -3
                                },
                                title: {
                                    text: 'OHLC'
                                },
                                height: '90%',
                                lineWidth: 2
                            }, {
                                labels: {
                                    align: 'right',
                                    x: -3
                                },
                                title: {
                                    text: 'Volume'
                                },
                                top: '85%',
                                height: '15%',
                                offset: 0,
                                lineWidth: 2
                            }
                        ],
                        xAxis: {
                            type: 'datetime',
                            tickPixelInterval: 75
                        },

                        rangeSelector: {
                            buttons: $scope.rangeButtons
                        },

                        series: $scope.series//,

                        //plotOptions: $scope.plotOptions
                    });
                };

                $scope.addSymbolToChart = function addSymbolToChart(symbol) {
                    if ($scope.symbols.length === 4) {
                        $scope.errorMessage = 'Maximum of 4 symbols allowed on chart. Could not add symbol';
                    } else {
                        var queryUrl = marketDataHelperObj.intradayDataUri(symbol, $scope.glx2, 1);
                        storage.async(queryUrl,
                            function success(data) {
                                $scope.processChartData(data.Data[0], $scope.symbols.length === 0 ? false : true);
                                $scope.createChart();
                            },
                            function failure(data) {
                                console.error(data);
                            });
                    }
                };

                $scope.removeSymbolFromChart = function removeSymbolFromChart(symbolToRemove) {
                    _.remove($scope.series, function(series) {
                        return series.name.indexOf(symbolToRemove) > -1;
                    });

                    _.remove($scope.symbols, function(symbol) {
                        return symbol === symbolToRemove;
                    });
                    $scope.createChart();
                };

                $scope.pubsubHandle = {
                    createChart: null
                };

                $scope.final = function () {
                    pubsub.unsubscribe($scope.pubsubHandle.createChart);      //unsubscribe on $destroy
                };

                $scope.init = function () {
                    auth.getGlxToken()
                        .then(function(glx2) {
                            $scope.glx2 = glx2;
                            //$scope.initChart();
                            $scope.settings = settings.getSettingsKeys;
                            $scope.pubsubHandle.createChart = pubsub.subscribe($scope.settings.chart.createchart, $scope.initChart);    //set up a listener for user clicks to the chart
                            if ($stateParams.DISP_NAME) {
                                $scope.initChart($stateParams.DISP_NAME);
                            }
                        });


                    $scope.$on('$destroy', $scope.final);

                };

                $scope.tearDown = function tearDown() {
                    $scope.symbols = [];
                    $scope.series = [];
                    $scope.emaSeries = [];
                };

                $scope.init();
            }
        ]);

        return chartWidget;
    });
