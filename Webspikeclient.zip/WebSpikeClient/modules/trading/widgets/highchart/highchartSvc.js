﻿
define([], function() {
  'use strict';

  var chartSvc = function() {

    var emaData = {};

    this.calculateEMA = function calculateEma(timeSeries, field) {
      var symbol = timeSeries[0].DISP_NAME;
      var averages = [];

      var oldEma = {};
      var allAverages = {};

      for (var n = 0; n < timeSeries.length; n++) {
        var pointEma;
        var point = {};
        var k = 2 / (n + 2);
        if (n === 0) {
          pointEma = (timeSeries[n][field] * k);
        } else {
          pointEma = (timeSeries[n][field] * k) + (oldEma.y * (1 - k));
        }
        point.k = k;
        point.n = n;
        point.y = pointEma;
        point.x = timeSeries[n].x;
        averages.push(point);
        oldEma = point;
      }
      emaData[symbol] = oldEma;
      allAverages[symbol] = averages;
      return averages;
    };

    this.addDataPoint = function addDataPoint(dataPoint) {
      var symbol = dataPoint.DISP_NAME;
      var pointEma;
      if (emaData[symbol] === 'undefined') {
        emaData[symbol].n = 1;
        emaData[symbol].k = 2 / (emaData[symbol].n + 2);
        pointEma = (dataPoint[field] * k);
      } else {
        emaData[symbol].n = emaData[symbol].n + 1;
        emaData[symbol].k = 2 / (emaData[symbol].n + 2);
        pointEma = (emaData[symbol][field] * emaData[symbol].k) + (emaData[symbol].y * (1 - emaData[symbol].k));
      }
      emaData[symbol] = pointEma;
      return pointEma;
    };

  }; //end svc


  chartSvc.$inject = ['$q', 'storage', 'settings'];

  return chartSvc;
});
