﻿'use strict';

define(['angular', 'angularDashboard', 'sortable', 'kendo', 'jquery'],
function (angular,adb,sort) {
	var tradingHomeWidget = angular.module('webSpike.trading.widget.home', ['adf.provider', 'kendo.directives']);

	var x = sort;

	tradingHomeWidget.config(function (dashboardProvider) {
		dashboardProvider
			.widget('tradingHomeWidget', {
			    title: 'Trading',
			    image: 'images/Trading_icon.svg',
				description: 'Trading Orders and Market Value',
				templateUrl: 'modules/trading/widgets/trading-home/_trading-home-view.html',
				controller: 'TradingHomeWidgetCtrl'
			});
	});

	tradingHomeWidget.controller('TradingHomeWidgetCtrl', ["$scope", function ($scope) {

		$scope.sellAmt = 2010877;
		$scope.buyAmt = 1703987;
		
		var recalc = function () {
			$scope.totalAmt = $scope.buyAmt + $scope.sellAmt;
			$scope.buyPct = Math.round($scope.buyAmt / $scope.totalAmt * 100);
			$scope.sellPct = 100 - $scope.buyPct;
		}
		recalc();
		
		// increment the sell amt every 2 seconds
		setInterval(function () {
			$scope.sellAmt = $scope.sellAmt + 231;
			recalc();
		}, 2000);
		
		$scope.tiles = [{
			num: 7,
			caption: 'New'
		},
		{
			num: 34,
			caption: 'Working'
		},
		{
			num: 22,
			caption: 'Rolled'
		},
		{
			num: 3,
			caption: 'Flagged'
		},
		{
			num: 1,
			caption: 'Done'
		},
		{
			num: 0,
			caption: 'Cancelled'
		}]

		$scope.chartseries = [{
			overlay: {
				gradient: 'none'
			},
			name: "mktvalue",
			data: [{
				category: "Buy",
				value: 46,
				color: "#7FC241"
			}, {
				category: "Sell",
				value: 54,
				color: "#D14B4C"
			}],
			labels: {
				visible: false,
				background: "transparent",
				position: "outsideEnd",
				template: "#= category #: \n #= value#%"
			}
		}];

	}]);

	return tradingHomeWidget;
});

