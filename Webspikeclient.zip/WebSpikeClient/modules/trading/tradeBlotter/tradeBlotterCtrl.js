﻿
define(function () {
    'use strict';

    function TradeBlotterController($scope,$rootScope) {
        $scope.model = {};

        $scope.setDashboardModel = function () {
            $scope.model = {
                structure: "TradingBlotterDashBoard",

                rows: [
                    {
                        columns: [
                            {
                                styleClass: "col-md-7 no-padding",
                                widgets: [{
                                    type: "tradeBlotterWidget",
                                    title: "Trade Blotter"
                                }]
                            },
                            {
                                styleClass: "col-md-5 no-padding",
                                widgets: [{
                                    type: "brokersFillsWidget",
                                    title: "Brokers & Fills"
                                }]
                            }
                        ]
                    },
                    {
                         columns: [
                            {
                                styleClass: "col-md-7 no-padding",
                                widgets: [{
                                    type: "level2Widget",
                                    title: "Level 2"
                                }]
                            },    
                            {
                                styleClass: "col-md-5 no-padding",
                                widgets: [{
                                    type: "symbolInfoWidget",
                                    title: "Symbol Info"
                                }]
                            }
                        ]
                    }
                ]
            };
        };

        $scope.launchTicket = $rootScope.launchTicket;

        $scope.init = function () {
            $scope.setDashboardModel();
        };

        $scope.init();
    }

    TradeBlotterController.$inject = ['$scope', '$rootScope'];

    return TradeBlotterController;

});
