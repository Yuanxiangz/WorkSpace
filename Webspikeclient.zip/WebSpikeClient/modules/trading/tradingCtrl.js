﻿
define(function () {
    'use strict';

    function TradingController($scope, hotkeys) {
        $scope.test = 'test';
        //This hotkey will only function while the bindTo scope is active.
        //? will open the hotkey menu and display available hotkeys.
        hotkeys.bindTo($scope).add({
            combo: "f2",
            description: "Open a ticket",
            callback: function () {
                $scope.launchTicket();

                event.preventDefault(); //Who knows what F2 was supposed to do?
            }
        });
    }

    TradingController.$inject = ['$scope','hotkeys'];

    return TradingController;

});
