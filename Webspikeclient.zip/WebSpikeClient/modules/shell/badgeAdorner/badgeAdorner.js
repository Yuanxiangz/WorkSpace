﻿define([], function() {

	return {
		name: "badgeAdorner",
		directive: function () {
			return {
				restrict: "E",
				templateUrl: "modules/shell/badgeAdorner/_badgeAdorner.html",
				transclude: true,
				scope: {
					icon: '=',
					notifications: '=?'
				},
				controller: function ($scope) {
					$scope.notifications = angular.isDefined($scope.notifications) ? $scope.notifications : 0;
				}
			}
		}
	}

});