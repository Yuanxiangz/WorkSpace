﻿define(["angular", "./badgeAdorner"], function(angular, badgeAdorner) {

	return angular.module("badgeAdorner", [])
		.directive(badgeAdorner.name, badgeAdorner.directive)
		.filter('notificationDisplayFilter', function() {
		return function(input) {

			if (input < 0) return "";
			else if (input < 10) return input;
			else return "*";

		};
	});

});