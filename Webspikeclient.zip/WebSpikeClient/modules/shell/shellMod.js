﻿'use strict';

define(['angular', './shellCtrl', './home/homeMod', './sideBar/sideBarMod', './messageCenter/messageCenterMod'],
	function (angular, shellMainController, homeModule, sideBarModule, messageCenterMod) {
    var shellModule = angular.module("webSpike.shell", [homeModule.name, sideBarModule.name, messageCenterMod.name]);
    shellModule.controller("ShellController", shellMainController);
    return shellModule;
});
