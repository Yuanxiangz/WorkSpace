﻿define(["angular", "./messageCenterCtrl"], function(angular, messageCenter) {

	return angular.module("webspike.shell.messageCenter", [])
		.controller("MessageCenterCtrl", messageCenter);

});