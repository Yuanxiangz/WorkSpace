﻿define(["angular", "lodash"], function(angular, _) {

	var ctrl = function($scope, notificationSvc) {

		$scope.notifications = [];

		notificationSvc.getAll().success(function(data) {

			for (var i = 0; i < data.length; i++) {
				$scope.notifications.push(data[i]);
			}

			notificationSvc.onCreated(function (notification) {

				$scope.$apply(function() {

					$scope.notifications.unshift(notification);

				});

			});

			notificationSvc.onChanged(function(notification) {

				$scope.$apply(function() {

					var existing = _.find($scope.notifications, { 'Id': notification.Id });

					if (existing) angular.copy(notification, existing);

				});

			});

		});

		$scope.message = "";

		$scope.action = "";

		$scope.markAsRead = function(notification) {

			notificationSvc.markAsRead(notification);

		};

		$scope.notify = function() {

			notificationSvc.create({
				Type: "Notification",
				Message: $scope.message, 
				ActionUrl: $scope.action
			});

		};

		$scope.alert = function() {

			notificationSvc.create({
				Type: "Alert",
				Message: $scope.message, 
				ActionUrl: $scope.action
			});

		};
	};

	ctrl.$inject = ["$scope", "notification"];

	return ctrl;

});