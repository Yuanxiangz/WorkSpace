﻿define([], function() {

	return {
		name: "sideBarItem",
		directive: function () {
			return {
				restrict: "E",
				templateUrl: "modules/shell/sideBar/_sideBarItem.html",
				transclude: true,
				replace: true,
				scope: {
					expanded: '=',
					selected: '@',
					state: '@',
					label: '@',
					icon: '@',
					notifications: '@?'
				},
				controller: function ($scope, $state) {
					$scope.notifications = angular.isDefined($scope.notifications) ? $scope.notifications : false;
				}
			}
		}
	}

});