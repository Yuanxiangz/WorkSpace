﻿define(['angular', './sideBarItem', '../badgeAdorner/badgeAdornerMod'], function(angular, sideBarItem, badgeAdorner) {

	return angular.module("webSpike.shell.sideBar", [badgeAdorner.name])
		.directive(sideBarItem.name, sideBarItem.directive);

});