﻿define(function () {
	'use strict';

	function HomeController($scope, $rootScope) {
		
		$scope.user = {
			firstName: "Harrison",
			lastName: "Teva",
			lastLoginTime: "Yesterday at 8:32am"
		};

		var model = {
			structure: "HomeDashBoard",
			// HomeDashboard has 2 rows, first row has 1 column with only 1 widget and second row has 2 columns
			rows: [
				{
					columns: [
						{
							styleClass: "col-md-12 no-padding",
							widgets: [{
								type: "news",
								title: "News & Announcements"
							}]
						}
					]
				},
				{
					columns: [
						{
							styleClass: "col-md-6 no-padding",
							widgets: [{
								type: "system",
								title: "System"
							},
							{
								type: "portfolioWidget",
								title: "Portfolio Summary"
							},
							{
								type: "reportingWidget",
								title: "Reporting"
							},
							]
						},
						{
							styleClass: "col-md-6 no-padding",
							widgets: [{
								type: "tradingHomeWidget",
								title: "Trading"
							}]
						}
					]
				}
			]
		};

		$scope.model = model;

		$scope.launchTicket = $rootScope.launchTicket;

		$scope.workflows = [
			{
				title: "Add new equity trade",
				description: "This is a trade template to input an equity trade with basic setup.",
				state: "trading.blotter"
			},
			{
				title: "Add new options trade",
				description: "This is a trade template to input an options trade with basic setup.",
				state: "trading.blotter"
			},
			{
				title: "Add new FX trade",
				description: "This is a trade template to input an FX trade with basic setup.",
				state: "home"
			},
			{
				title: "Add new fixed income trade",
				description: "This is a trade template to input an fixed income trade with basic setup.",
				state: "trading"
			},
			{
				title: "Buy US Equity",
				description: "This is a trade template to input a US based equity trade with basic setup.",
				state: "trading"
			},
			{
				title: "Sell US Equity",
				description: "This is a trade template to input a sell order for a US based equity trade with basic setup.",
				state: "trading"
			},
			{
				title: "Buy 1,000 AAPL",
				description: "This is a trade template to buy an order of quantity 1,000 for Apple Inc. (AAPL) equity with default brokers.",
				state: "trading"
			}
		];
	}

	HomeController.$inject = ['$scope', '$rootScope', 'hotkeys'];

	return HomeController;

});