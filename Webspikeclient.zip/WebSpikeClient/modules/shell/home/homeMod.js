﻿'use strict';

define(['angular', 'angularDashboard', './homeCtrl'],
function (angular, adf, homeController) {

	var homeModule = angular.module('webSpike.shell.home', ['adf']);

	homeModule.controller('HomeCtrl', homeController);

	// homeModule configuration
	homeModule.config(["dashboardProvider",
	function (dashboardProvider) {

		dashboardProvider.structure('HomeDashBoard', {
			rows: [
				{
					columns: [
						{
							styleClass: 'col-md-12'
						}
					]
				}, {
					columns: [
						{
							styleClass: 'col-md-6'
						},
						{
							styleClass: 'col-md-6'
						}
					]
				}
			]
		});

	}]);

	return homeModule;
});