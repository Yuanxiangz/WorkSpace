
define(["lodash"], function (_) {

	var ctrl = function ($scope, $state, $rootScope, $window, $stateParams, $modal, notificationSvc, hotkeys) {

		$scope.init = function () {

			updateUnread();

		};

    	$scope.isFullShell = !($stateParams.shellType && ($stateParams.shellType === 'workroom' || $stateParams.shellType === 'popout'));
    	$scope.isPopout = $stateParams.shellType === 'popout';

		var getStateIcon = function (state) {
			return state.data != null
				? state.data.icon != null
					? state.data.icon
					: "images/Trading_icon.svg"
				: "images/Trading_icon.svg";
		}

		var getStateName = function (state) {
			return state.data != null
				? state.data.display != null
					? state.data.display
					: state.name
				: state.name;
		}

		var makePretty = function (state) {
			return {
				state: state.name,
				icon: getStateIcon(state),
				label: getStateName(state)
			}
		};

		var getPrimaryState = function () {
			return _($state.get())
				.filter(function (s) { return $state.includes(s.name); })
				.filter(function (s) { return s.parent === 'shell'; })
				.first();
		}

		var getPrimaryStates = function () {
			return _($state.get())
				.filter(function (s) { return s.parent === 'shell'; })
				.filter(function (s) { return s.name != 'home'; })
				.filter(function (s) { return s.name != 'messageCenter'; }) //Home and Message Center are special. 
				.map(makePretty)
				.value();
		};

		var getSecondaryStates = function () {
			var primaryState = getPrimaryState();
			return _($state.get())
				.filter(function (s) { return s.parent === primaryState.name; })
				.map(makePretty)
				.value();
		};

		var addAlert = function (notification) {
			$scope.alerts.unshift(notification);

		};

		// register hotkeys for state transitions from main page
		if ($scope.isFullShell) {
			$state.get().forEach(function (state) {
				if (state.data && state.data.hotkey) {
					hotkeys.bindTo($scope).add({
						combo: state.data.hotkey,
						description: "Go to " + state.data.display + " workspace",
						callback: function () {
							$state.transitionTo(state);
							event.preventDefault();
						}
					});

					hotkeys.bindTo($scope).add({
						combo: "alt+w " + state.data.hotkey,
						description: "Go to " + state.data.display + " workspace",
						callback: function () {
							openInNewWindow(state);
							event.preventDefault();
						}
					});
				}
			});
		}

		$scope.clearAlert = function () {
			$scope.alerts.shift();

		};

		$scope.markAlertAsRead = function () {

			notificationSvc.markAsRead($scope.alerts[0]);

			$scope.clearAlert();

		};

		$rootScope.$on('$stateChangeSuccess',
			function (event, toState, toParams, fromState, fromParams) {

				$scope.currentPrimaryState = makePretty(getPrimaryState());

				$scope.tabBarItems = getSecondaryStates();
				$scope.currentSecondaryState = _($scope.tabBarItems).find(function (state) {
					return state.state === toState.name;
				});
			});

		$scope.toggleSideBar = function () {
			this.sideBarExpanded = !this.sideBarExpanded;
		};

		$scope.$state = $state;

		$scope.sideBarItems = getPrimaryStates();

		$scope.tabBarItems = getSecondaryStates();

		$scope.currentPrimaryState = makePretty(getPrimaryState());

		$scope.currentSecondaryState = _($scope.tabBarItems).find(function (state) {
			return state.state === $state.current.name;
		});

		$scope.onNavContextMenuSelect = function (e) {
			//If "Open in new window"
			if (e.item.attributes['contextmenu-id'].value === "1") {
				openInNewWindow(e.target.attributes['contextmenu-model'].value);
			}
		};

		var openInNewWindow = function (destination) {
			$window.open($state.href(destination, { shellType: "workroom" }), destination, "toolbar=no");
		};

		$scope.isElectron = isElectron;

		// begin: functions only for use by electron desktop shell

		if (isElectron) {
			$scope.openWindows = {};
			var remote = require('remote');
			var browserWindow = remote.require('browser-window');

			openInNewWindow = function (destination) {
				var dest = 'file://' + __dirname + '/index.html' + $state.href(destination, { shellType: "workroom" });
				var popupWin = new browserWindow({ width: 800, height: 800, frame: false });
				popupWin.loadUrl(dest);
				$scope.openWindows[popupWin.id] = popupWin;
				popupWin.on('closed', function () {
					popupWin = null;
				});
			};

			$scope.closeApp = function () {
				browserWindow.getFocusedWindow().close();
			};

			$scope.minApp = function () {
				browserWindow.getFocusedWindow().minimize();
			};

			$scope.maxApp = function () {
				browserWindow.getFocusedWindow().maximize();
			};
		}

		// end: electron functions
		$scope.alerts = [];

		//It's not preferable to have this here, but I don't quite have the syntax down for putting this info
		//in the markup itself. - Matt C
		$scope.notificationPosition = {
			pinned: false,
			top: 20,
			right: 20,
			bottom: null,
			left: null
		}

		var showNotificationInBrowser = function (notification) {
			switch (notification.Type) {
				case "Notification":
					if ($scope.notifications) {
						$scope.notifications.show(notification.Message);
					}
					break;

				case "Alert":
					if ($scope.alerts) {
						$scope.$apply(function () { addAlert(notification); });
					}
					break;

				default:
			}
		}

		var updateUnread = function () {
			notificationSvc.getUnread().success(function (data) {
				$scope.unreadMessages = data.length;
			});
		};

		var showNotificationInOperatingSystem = function (notification) {
			var remote = require("remote");
			var trayIcon = remote.getGlobal("trayIcon");
			trayIcon.displayBalloon({ title: notification.Type, content: notification.Message });
		};

		notificationSvc.onCreated(function (notification) {
			if (notification && notification.Message && notification.Type) {
				showNotificationInBrowser(notification);
				if (isElectron && $scope.isFullShell) showNotificationInOperatingSystem(notification);
			}
			updateUnread();
		});

		notificationSvc.onChanged(function (notification) {
			updateUnread();
		});

		$scope.init();
	};

	ctrl.$inject = ['$scope', '$state', '$rootScope', '$window', '$stateParams', '$modal', 'notification', 'hotkeys'];

	return ctrl;

});

