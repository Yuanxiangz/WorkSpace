﻿'use strict';

define(['angular', './operationsCtrl'],
function (angular, operationsCtrl) {

	var operations = angular.module('eze.operations', []);

	operations.controller('operationsCtrl', operationsCtrl);

	return operations;

});
