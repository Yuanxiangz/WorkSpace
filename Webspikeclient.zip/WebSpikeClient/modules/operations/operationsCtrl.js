﻿define(function () {
    'use strict';

    function OperationsMainController($scope) {
    }

    OperationsMainController.$inject = ['$scope'];

    return OperationsMainController;

});
