﻿define(["jquery", "lodash", "signalR"], function ($, _) {
    'use strict';

    function portofolioODataController($scope, $http, settings) {

        var signalrUrl = settings.webApiEndpointHostname + "/WebApiService/signalr";

        var connection = $.hubConnection(signalrUrl, { useDefaultPath: false });

        var proxy = connection.createHubProxy('analyticsPositionsHub');

        var updateSource;
        proxy.on('onChanged', function (notification) {
            updateSource(notification);
        });

        var startPromise = connection.start();
        var currentSubscriptions = [];

        startPromise.done(function () { console.log('Now connected, connection ID=' + $.connection.hub.id); })
			.fail(function () { console.log('Could not Connect!'); });

        var dataSource = new kendo.data.DataSource({
            type: "odata",
            transport: {
                read: {
                    url: settings.webApiEndpointHostname + "/Webapiservice/analytics/odata/AnalyticsPositions",
                    dataType: "json"
                },
                push: function (callbacks) {
                    updateSource = function (data) {
                        var updates = [];
                        data.forEach(function (item) {
                            if (currentSubscriptions.indexOf(item.Id) != -1) {
                                updates.push(item);
                            }
                        });
                        dataSource.pushUpdate(updates);
                        //callbacks.pushUpdate({ 'value': updates });
                    }
                }
            },
            pageSize: 15,
            serverPaging: true,
            serverSorting: true,
            serverGrouping: true,
            sortable: true,
            sort: ({ field: "Id", dir: "asc" }),
            change: function (e) {

                if (!e.action) {
                    var dataInView = dataSource.view();
                    var ids = _.map(dataInView, function (x) {
                        return x.Id;
                    });

                    currentSubscriptions = ids;
                    startPromise.done(function () {
                        proxy.invoke('subscribe', ids);
                    });

                    console.log("In Page: " + dataSource.page() + " Ids: " + currentSubscriptions);
                }
            },
            schema: {
                data: "value",
                total: function (data) {
                    return data['@odata.count']; // <-- The total items count is the data length, there is no .Count to unpack.
                },
                group: function (data) {
                    return data.value;
                },
                model: {
                    id: "Id",
                    fields: {
                        "Id": {
                            editable: false,
                            type: "number"
                        },
                        "Symbol": {
                            editable: false,
                            type: "string"
                        },
                        "Price": {
                            editable: false,
                            type: "number"
                        },
                        "BuyPrice": {
                            editable: false,
                            type: "number"
                        },
                        "PL": {
                            editable: false,
                            type: "number"
                        },
                        "Shares": {
                            editable: false,
                            type: "number"
                        }
                    }
                }
            }
        });

        $("#analyticsOdataGrid").kendoGrid({
            dataSource: dataSource,
            sortable: true,
            scrollable: {
                virtual: true
            },
            columns: [
				{ field: 'Id', width: 50 },
				{ field: 'Symbol', width: 100 },
				{ field: 'Portfolio', width: 100 },
				{ field: 'AssetClass', width: 150 },
				{ field: 'Sector', width: 130 },
				{ field: 'Type', width: 60 },
				{ field: 'PL', width: 130, template: "#=changeTemplate(PL, kendo.toString(PL, 'n2')) #" },
				{ field: 'Price', width: 100, title: 'Price*', format: "{0:c2}" },
				{ field: 'PrcPct', width: 100, title: 'Prc%', template: '#: PrcPct # %' },
				{ field: 'Amount', width: 100, format: "{0:n0}" },
				{ field: 'MktVal', width: 100, format: "{0:c2}" },
				{ field: 'MktValPct', width: 100, title: 'MktVal%' },
				{ field: 'PrtModelPct', width: 100, title: 'PrtModel%' },
				{ field: 'Exposure', width: 100, format: "{0:n0}" },
				{ field: 'PLBS', width: 100 },
				{ field: 'MTDPL', width: 100 },
				{ field: 'MktDataSource', width: 100 },
            ]
        });

    }

    portofolioODataController.$inject = ['$scope', '$http', 'settings'];

    return portofolioODataController;

});