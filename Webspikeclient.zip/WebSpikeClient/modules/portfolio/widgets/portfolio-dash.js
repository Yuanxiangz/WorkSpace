﻿define(['angular', 'angularDashboard'],
function (angular) {

	var widget = angular.module('eze.portfolio.widget.portfolio', ['adf.provider']);

	widget.config(function (dashboardProvider) {
		dashboardProvider
			.widget('portfolioWidget', {
				title: 'Portfolio Summary',
				image: 'images/portfolio-icon.svg',
				description: 'Portfolio Summary',
				templateUrl: 'modules/portfolio/widgets/_portfolio-dash.html',
				controller: 'PortfolioWidgetController',
				controllerAs: 'Portfolio',
				config: { }
			});
	});

	widget.controller('PortfolioWidgetController', function ($scope, config) {
		
		$scope.weather = new kendo.data.DataSource({
			transport: {
				read: {
					//TODO: replace with stubbed backend
					url: "http://demos.telerik.com/kendo-ui/service/Weather/SOFIA/2012/1",
					dataType: "jsonp"
				}
			}
		});

	});

	return widget;

});