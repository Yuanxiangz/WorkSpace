﻿define(["jquery", "lodash"], function ($, _) {
	'use strict';

	function EzePortfolioController($scope, $http, settings) {

		//var connection = $.hubConnection('http://localhost/skdp5web/signalr', { useDefaultPath: false });
		var connection = $.hubConnection('http://skdp5web2.azurewebsites.net/signalr', { useDefaultPath: false });
		var proxy = connection.createHubProxy('tickHub');

		$scope.paused = false;
		proxy.on("update", function (message) {
			if (!$scope.paused) {
				var data = JSON.parse(message);
				var grid = $("#AnalyticsGrid").data("kendoGrid");

				if (grid.dataSource._data.length === 0) {
					grid.dataSource.data(data.Payload);
				}
				else {
					var arry = $scope.$eval(message);
					arry.Payload.forEach(function (updatedItem) {

						var row = _.find(grid.dataSource._data, { 'Id': updatedItem.Id });
						copyValues(row, updatedItem);
					});
					grid.refresh();
				}

			}
		});

		function copyValues(target, source) {
			target.PL = source.PL;
			target.Price = source.Price;
			target.Amount = source.Amount;
			target.MktVal = source.MktVal;
			target.PrcPct = source.PrcPct;
			target.MktValPct = source.MktValPct;
			target.PrtModelPct = source.PrtModelPct;
			target.Exposure = source.Exposure;
			target.PLBS = source.PLBS;
			target.MTDPL = source.MTDPL;
		}

		var hubStart = connection.start()
			.done(function () { console.log('Now connected, connection ID=' + $.connection.hub.id); })
			.fail(function () { console.log('Could not Connect!'); });

		var positionsData = {
			data: [],
			pageSize: 23
		};

		$scope.togglePause = function () {
			$scope.paused = !$scope.paused;
		};

		$scope.positions = new kendo.data.DataSource(positionsData);
		
		$scope.gridOptions = {
			scrollable: {
				virtual: true
			},
			resizable: true,
			groupable: true,
			selectable: 'row',
			sortable: true,
			columns: [
				{ field: 'Symbol',	     width: 100},
				{ field: 'Portfolio',	 width: 100},
				{ field: 'AssetClass',	 width: 150},
				{ field: 'Sector',	     width: 130},
				{ field: 'Type',         width: 60 },
				{ field: 'PL',           width: 130, template: "#=changeTemplate(PL, kendo.toString(PL, 'n2')) #" },
				{ field: 'Price',        width: 100, title: 'Price*', format: "{0:c2}" },
				{ field: 'PrcPct',       width: 100, title: 'Prc%', template: '#: PrcPct # %' },
				{ field: 'Amount',       width: 100, format: "{0:n0}" },
				{ field: 'MktVal',	     width: 100, format: "{0:c2}"},
				{ field: 'MktValPct',    width: 100, title: 'MktVal%' },
				{ field: 'PrtModelPct',  width: 100, title: 'PrtModel%' },
				{ field: 'Exposure',     width: 100, format: "{0:n0}" },
				{ field: 'PLBS',	     width: 100},
				{ field: 'MTDPL',	     width: 100},
				{ field: 'MktDataSource', width: 100},
			]
		};
	}

	EzePortfolioController.$inject = ['$scope', '$http', 'settings'];

	return EzePortfolioController;

});

function changeTemplate(value, str) {
	if (value > 0) {
		return "<span style='color:#7FC241;white-space:nowrap'>&#x25B2; " + str + "</span>";
	}
	else {
		return "<span style='color:#D14B4C;white-space:nowrap'>&#x25BC; " + str + "</span>";
	}
}