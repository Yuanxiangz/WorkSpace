﻿'use strict';

define(['angular',
	'modules/portfolio/portfolioCtrl',
	'modules/portfolio/summary/portfolioSummaryCtrl',
	'modules/portfolio/analytics/analyticsCtrl',
	'modules/portfolio/odata/odataCtrl',
	'./widgets/portfolio-dash',
	'jquery',
	'signalR'],
function (angular, portfolioController, summaryController, analyticsController, odataController, portWidget, $) {

	var portfolio = angular.module('eze.portfolio', [portWidget.name]);

	portfolio.controller('portfolioCtrl', portfolioController);
	portfolio.controller('portfolioSummaryCtrl', summaryController);
	portfolio.controller('analyticsCtrl', analyticsController);
	portfolio.controller('portfolioOdataCtrl', odataController);

	return portfolio;

});
