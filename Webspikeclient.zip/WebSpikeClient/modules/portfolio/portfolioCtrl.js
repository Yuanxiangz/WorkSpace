﻿define(["jquery", "signalR"], function ($) {
	'use strict';

	function EzePortfolioController($scope, $http, settings) {

		
	}

	EzePortfolioController.$inject = ['$scope', '$http', 'settings'];

	return EzePortfolioController;

});
