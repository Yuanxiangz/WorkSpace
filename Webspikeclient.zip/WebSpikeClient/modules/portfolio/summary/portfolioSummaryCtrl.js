﻿
define(function () {
	'use strict';

	function EzePortfolioController($scope) {
		$scope.model = {};

		$scope.setDashboardModel = function () {
			$scope.model = {
				structure: "portfolioDashboard",

				rows: [
                    {
                    	columns: [
						    {
						    	styleClass: "col-md-4 no-padding",
						    	widgets: [
								    {
								    	type: "portfolioWidget",
								    	title: "Portfolio Summary"
								    }
						    	]
						    }
                    	]
                    },
	                {
	                	columns: []
	                }
				]
			};
		};


		$scope.init = function () {
			$scope.setDashboardModel();
		};

		$scope.init();
		
	}

	EzePortfolioController.$inject = ['$scope'];

	return EzePortfolioController;

});
