﻿define(function () {
    'use strict';

    function ComplianceMainController($scope) {
    }

    ComplianceMainController.$inject = ['$scope'];

    return ComplianceMainController;

});
