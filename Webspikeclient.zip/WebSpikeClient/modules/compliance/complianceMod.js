﻿
define(['angular', './complianceCtrl'],
function (angular, complianceController) {
    'use strict';

    var compliance = angular.module('eze.compliance', []);

	compliance.controller('complianceCtrl', complianceController);

	return compliance;

});
