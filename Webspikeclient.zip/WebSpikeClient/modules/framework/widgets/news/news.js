﻿define(['angular', 'angularDashboard'],
function (angular) {

	var newsWidget = angular.module('webSpike.framework.widget.news', ['adf.provider']);

	newsWidget.config(function (dashboardProvider) {
		dashboardProvider
			.widget('news', {
				title: 'News & Announcements',
				image: 'images/News_Alerts_Icon.svg',
				description: 'Latest news and announcements',
				templateUrl: 'modules/framework/widgets/news/_news.html',
				controller: 'NewsWidgetController',
				controllerAs: 'news',
			});
	});

	newsWidget.controller('NewsWidgetController', function ($scope) {

		$scope.newsItems = [
			{
				heading: "New Trade Type Released",
				description : "This morning you will find that there is a new trade type available in your system"
			},

			{
				heading: "Eze IMS wins awards",
				description: 'Today Eze IMS won awards from the industry for being the "most innovative and ground breaking software for hedge funds"'
			},

			{
				heading: "New Risk Feature",
				description: "The Curverator has been enhanced to support polynomial and spline interpolation."
			}
		];

	});

	return newsWidget;

});