﻿'use strict';

define(['angular', './news/news', './system/system'],
function (angular, news, system) {

	var frameworkWidgets = angular.module('webSpike.framework.widgets', [news.name, system.name]);


	return frameworkWidgets;

});