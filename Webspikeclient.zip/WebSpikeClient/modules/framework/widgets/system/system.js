﻿define(['angular', 'angularDashboard'],
function (angular) {

	var systemWidget = angular.module('webSpike.framework.widget.system', ['adf.provider']);

	systemWidget.config(function (dashboardProvider) {
		dashboardProvider
			.widget('system', {
				title: 'System',
				image: 'images/system-icon.svg',
				description: 'System Status',
				templateUrl: 'modules/framework/widgets/system/_system.html',
				controller: 'SystemWidgetController',
				controllerAs: 'system',
				config: { }
			});
	});

	systemWidget.controller('SystemWidgetController', function ($scope, config) {
		
		$scope.timeTilClose = "3 hours 38 mins";
	});

	return systemWidget;

});