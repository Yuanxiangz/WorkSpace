﻿'use strict';

// This is the package main of the framework CommonJs package

// configure framework packages
requirejs.config({
	packages: [
		{ name: 'framework.services', location: 'modules/framework/services' },
		{ name: 'framework.widgets', location: 'modules/framework/widgets' }
	]
});

define(['angular', 'framework.services', 'framework.widgets'],
function (angular,services,widgets) {

	return angular.module('webSpike.framework', [services.name, widgets.name]);

});