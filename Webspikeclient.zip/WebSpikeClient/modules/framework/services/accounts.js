﻿define(['angular', 'lodash'],
function (angular, _) {
    'use strict';

    var accountService = function ($http, $q, settings, storage, auth) {
        this.glx2 = '';
        this.routeByAccount = {};
        this.bbcdXperms = {};
        var self = this;

        this.getBBCDXPerms = function () {
            var deferred = $q.defer();
            if (self.bbcdXperms.bbcd) {
                deferred.resolve(self.bbcdXperms);
            } else {
                auth.getGlxToken()
                .then(function (glx) {
                    storage.async(settings.apiEndpointHostname + 'data/trade.bbcdxperms?feature=' + 'USER' + '&glx=' + glx +
                        '&locale=' + encodeURIComponent('rotr_dev_locale'),
                        function (data, status, headers, config) {
                            _.each(data.Data.bbcd, function (element, index, list) {
                                if (!element.ShortName) {
                                    element.ShortName = element.AcctDesc;
                                }
                            });

                            if (data.Data.bbcd && data.Data.bbcd.length > 1) {
                                data.Data.bbcd.unshift({
                                    "Bank": "*",
                                    "Branch": "*",
                                    "Customer": "*",
                                    "Deposit": "*",
                                    "MarginRule setName": "",
                                    "AcctDesc": "*;*;*;*",
                                    "AcctId": 0,
                                    "UserId": data.Data.bbcd[0].UserId,
                                    "CustAdmUserId": data.Data.bbcd[0].CustAdmUserId,
                                    "ShortName": "ALL ACCOUNTS"
                                });
                            }

                            self.bbcdXperms = data.Data;
                            deferred.resolve(data.Data);
                        },
                        function (data, status, headers, config) { // on ajax exception
                            deferred.reject(data, status);
                        }
                    );
                });
            }

            return deferred.promise;
        };

        this.getRoutes = function (account) {
            var deferred = $q.defer();
            if (self.routeByAccount[account.AcctId]) {
                deferred.resolve(self.routeByAccount[account.AcctId]);
            } else {
                auth.getGlxToken()
                .then(function (glx) {
                    storage.async(settings.apiEndpointHostname + '/data/trade.getroutes?feature=' + 'USER' + '&glx=' + glx
                        + "&locale=" + encodeURIComponent('rotr_dev_locale')
                        + "&bbcd=" + encodeURIComponent(account.Bank + ';' + account.Branch
                            + ";" + account.Customer + ";" + account.Deposit),
                        function (data, status, headers, config) {
                            self.routeByAccount[account.AcctId] =
                                _.filter(data.Data, function (route) {
                                    return !(route.AlgoType !== "" && route.ATDLType === "");
                                });
                            deferred.resolve(self.routeByAccount[account.AcctId]);
                        },
                      function (data, status, headers, config) { // on ajax exception
                          deferred.reject(data);
                      }
                  );
                });
            }

            return deferred.promise;
        };
    };

    accountService.$inject = ['$http', '$q', 'settings', 'storage', 'auth'];

    return accountService;

});