﻿define([], function () {
    "use strict";

    var streamingSvc = function ($q, auth, settings, pubsub, storage) {
        /*  SignalR Connection States
            0: 'connecting'
            1: 'connected'
            2: 'reconnecting'
            4: 'disconnected'
        */

        //#region Private
        var _settings = settings.getSettingsKeys;
        var connection = null,
            userEnabled = false,
            state = 4,
            message = {
                subId: null,
                message: {}
            };

        var authenticate = function () {
            var deferred = $q.defer();
            auth.getGlxToken()
            .then(function (glx) {
                connection.server.authenticate(glx)
                .done(function (bool) {
                    deferred.resolve(bool);
                })
                .fail(function () {
                    console.log("fail authenticating");
                    connection = null;
                    deferred.resolve(false);
                });
            });

            return deferred.promise;
        };

        var registerClientFunction = function (methodName, func) {
            if (methodName && typeof methodName === "string" &&
                func && typeof func === "function") {

                connection.client[methodName] = func;
            }
        };

        var invokeServerMethod = function (methodName, argument, doneFunc, failFunc) {
            if (methodName && typeof methodName === "string" &&
                argument && typeof argument === "object" &&
                doneFunc && typeof doneFunc === "function" &&
                failFunc && typeof failFunc === "function") {

                connection.server[methodName](argument).done(doneFunc).fail(failFunc);
            }
        };
        //#endregion

        //#region Public interface
        this.subscribe = function (queryProcessor, subscriptionInfo, callBack) {
            var deferred = $q.defer();

            if (connection &&
                queryProcessor && typeof queryProcessor === "string" &&
                subscriptionInfo && typeof subscriptionInfo === "object" &&
                callBack && typeof callBack === "function") {

                connection.server.subscribe(queryProcessor, subscriptionInfo)
                    .done(function (data) {
                        var subInfo = {
                            subscriptionInfo: subscriptionInfo,
                            subId: data.subId,
                            pubsubHandle: null
                        };
                        if (data.succeeded) {
                            subInfo.pubsubHandle = pubsub.subscribe(data.subId, callBack);
                            callBack(data.initial);
                            deferred.resolve(subInfo);
                        } else {
                            deferred.resolve(null);
                        }
                    }).fail(function (error) {
                        deferred.resolve(null);
                    });
            } else {
                deferred.resolve(null);
            }
            return deferred.promise;
        };

        this.unsubscribe = function (subInfo) {
            if (subInfo && typeof subInfo === "object" &&
                subInfo.pubsubHandle && subInfo.subId) {

                pubsub.unsubscribe(subInfo.pubsubHandle);

                if (connection) {
                    connection.server.unsubscribe(subInfo.subId)
                        .done(function () { })
                        .fail(function () { });
                }
            }
        };

        this.request = function (queryProcessor, request, callback) {
            if (connection &&
                queryProcessor && typeof queryProcessor === "string" &&
                request && typeof request === "object" &&
                callBack && typeof callBack === "function") {

                connection.server.request(queryProcessor, request)
                    .done(function (data) {
                        if (data.succeeded) {
                            callBack(data.response);
                        }
                    }).fail(function (error) {
                    });
            }
            return null;
        };

        this.setUserEnabled = function (_enabled) {
            userEnabled = _enabled;
            if (this.enabled()) {
                pubsub.publish(_settings.streaming.connected, [true], true);
            } else if (!_enabled && this.available()) { //connected, but the user has turned off the feature
                pubsub.publish(_settings.streaming.disconnected, [true], true);
            }
        };

        this.available = function () {
            return (connection && state === 1);
        };

        this.enabled = function () {
            return (connection && state === 1 && userEnabled);
        };


        this.streamingIsChecked = function () {
            //return userSvc.user.streaming;
            return true;
        };

        //#endregion

        this.init = function () {
            var deferred = $q.defer();

            if ($.connection && $.connection.realTimeHub) {
                connection = $.connection.realTimeHub;
                connection.logging = true;

                $.connection.hub.reconnected(function () {
                    //console.log("reconnected");
                    authenticate().then(function () {
                        if (connection) {
                            pubsub.publish(_settings.streaming.connected, [true], true);
                        }
                    });
                });
                $.connection.hub.stateChanged(function (_state) {
                    state = _state.newState;
                });
                $.connection.hub.disconnected(function () {
                    connection = null;
                    pubsub.publish(_settings.streaming.disconnected, [true], true);
                });
                $.connection.hub.error(function (error) {
                });

                connection.client.sendMessage = function (message) {
                    pubsub.publish(message.subId, [message.message]);
                };

                connection.client.disconnect = function () {
                    var glx = storage.getFromSessionStorage("user.glx");
                    storage.clearSessionStorage();
                };

                $.connection.hub.start({ transport: ['webSockets', 'serverSentEvents', 'longPolling'], xdomain: true }).done(function () {
                    authenticate();
                    deferred.resolve();
                }).fail(function () {
                    deferred.resolve();
                });
            } else {
                deferred.resolve();
            }

            return deferred.promise;
        };
    };

    streamingSvc.$inject = ['$q', 'auth', 'settings', 'pubsub', 'storage', 'settings'];

    return streamingSvc;
});