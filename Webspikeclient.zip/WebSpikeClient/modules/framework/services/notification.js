﻿define(["jquery", "signalR"], function($) {

	var service = function(pubsub, $http, settings) {

		var CREATED_TOPIC = "notificationCreated";

		var CHANGED_TOPIC = "notificationChanged";

		var NOTIFICATION_PATH = "/WebApiService/api/notifications";

		var SIGNALR_PATH = "/WebApiService/signalr";

		var NOTIFICATION_URL = settings.webApiEndpointHostname + NOTIFICATION_PATH;

		var SIGNALR_URL = settings.webApiEndpointHostname + SIGNALR_PATH;

		var connection = $.hubConnection(SIGNALR_URL, { useDefaultPath: false });

		var proxy = connection.createHubProxy('notificationHub');

		proxy.on('onCreated', function (notification) {
			pubsub.publish(CREATED_TOPIC, [notification], true);
		});

		proxy.on('onChanged', function (notification) {
			pubsub.publish(CHANGED_TOPIC, [notification], true);
		});

		connection.start()
			.done(function(){ console.log('Now connected, connection ID=' + $.connection.hub.id); })
			.fail(function(){ console.log('Could not Connect!'); });

		return {
			getAll: function() {
				return $http.get(NOTIFICATION_URL);
			},
			create: function(notification) {
				return $http.post(NOTIFICATION_URL, notification);
			},
			markAsRead: function(notification) {
				notification.IsRead = true;
				return $http.put(NOTIFICATION_URL, notification);
			},
			onCreated: function(callback) {
				return pubsub.subscribe(CREATED_TOPIC, callback);
			},
			onChanged: function(callback) {
				return pubsub.subscribe(CHANGED_TOPIC, callback);
			},
			unsubsribe: function(handle) {
				pubsub.unsubscribe(handle);
			},
			getUnread: function() {
				return $http.get(NOTIFICATION_URL + "/unread");
			}
		}
	};

	service.$inject = ['pubsub', '$http', 'settings'];

	return service;

});