﻿define(function () {
    "use strict";

    var service = function ($http, $rootScope) {
        var storage = {
            cookie: { expiry: 30, path: '/' },
            async: function (url, success, error, elem) {
                var promise = $http.get(url)
                    .success(function (data, status, headers, config) {
                        if (data && data.Info && data.Info.TimeStamp) {
                            if (data) { if (data.Info) { $rootScope.$broadcast('lastUpdate', data.Info.TimeStamp); } }
                        }
                        success(data, status, headers, config);
                    })
                    .error(function (data, status, headers, config) {
                        if (data && data.Info && data.Info.TimeStamp) {
                            if (data) { if (data.Info) { $rootScope.$broadcast('lastUpdate', data.Info.TimeStamp); } }
                        }
                        error(data, status, headers, config);
                    });
                return promise;
            },
            asyncPost: function (url, data, success, error) {
                var promise = $http.post(url, data)
                    .success(function (data, status, headers, config) {
                        if (data.Info && data.Info.TimeStamp) {
                            if (data) { if (data.Info) { $rootScope.$broadcast('lastUpdate', data.Info.TimeStamp); } }
                        }
                        success(data, status, headers, config);
                    })
                    .error(function (data, status, headers, config) {
                        if (data.Info && data.Info.TimeStamp) {
                            if (data) { if (data.Info) { $rootScope.$broadcast('lastUpdate', data.Info.TimeStamp); } }
                        }
                        error(data, status, headers, config);
                    });
                return promise;
            },
            asyncPostForm: function (url, data, success, error) {  //ATDL needs to post as a Form
                var promise = $http({
                    method: 'POST',
                    url: url,
                    data: data,
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                }).success(success).error(error);
                return promise;
            },

            // **** session storage **** 

            browserSupportsSessionStorage: function () {
                try {
                    if ('sessionStorage' in window && window['sessionStorage'] !== null) {
                        window.sessionStorage.setItem('qeTest', '1');
                        window.sessionStorage.removeItem('qeTest');
                        return true;
                    }
                    return false;
                } catch (e) {
                    return false;
                }
            },
            // Directly adds a value to session storage
            // If session storage is not available in the browser use cookies
            addToSessionStorage: function (key, value) {

                // If this browser does not support session storage use cookies
                if (!this.browserSupportsSessionStorage()) {
                    return this.addToCookies(key, value);
                }

                // 0 and "" is allowed as a value but let's limit other falsey values like "undefined"
                if (!value && value !== 0 && value !== "") return false;

                try {
                    sessionStorage.setItem(key, value);
                } catch (e) {
                    return this.addToCookies(key, value);
                }
                return true;
            },
            getFromSessionStorage: function (key) {
                if (!this.browserSupportsSessionStorage()) {
                    return this.getFromCookies(key);
                }

                var item = sessionStorage.getItem(key);
                if (!item) return null;
                return item;
            },
            removeFromSessionStorage: function (key) {
                if (!this.browserSupportsSessionStorage()) {
                    return this.removeFromCookies(key);
                }

                try {
                    sessionStorage.removeItem(key);
                } catch (e) {
                    return this.removeFromCookies(key);
                }
                return true;
            },
            clearSessionStorage: function () {
                if (this.browserSupportsSessionStorage()) {
                    try {
                        sessionStorage.clear();
                    } catch (e) {

                    }
                    return true;
                }
            },
            doesSessionStorageKeyExist: function (key) {
                if (!this.browserSupportsSessionStorage()) {
                    return this.getFromCookies(key);
                }

                var item = sessionStorage.getItem(key);
                if (!item) return false;
                return true;
            },


            // **** local storage **** 

            // Directly adds a value to local storage
            // If local storage is not available in the browser use cookies
            // Example use: localStorageService.add('library','angular');

            browserSupportsLocalStorage: function () {
                try {
                    return ('localStorage' in window && window['localStorage'] !== null);
                } catch (e) {
                    return false;
                }
            },

            addToLocalStorage: function (key, value) {

                // If this browser does not support local storage use cookies
                if (!this.browserSupportsLocalStorage()) {
                    return this.addToCookies(key, value);
                }

                // 0 and "" is allowed as a value but let's limit other falsey values like "undefined"
                if (!value && value !== 0 && value !== "") return false;

                try {
                    localStorage.setItem(key, value);
                } catch (e) {
                    return this.addToCookies(key, value);
                }
                return true;
            },
            getFromLocalStorage: function (key) {
                if (!this.browserSupportsLocalStorage()) {
                    return this.getFromCookies(key);
                }

                var item = localStorage.getItem(key);
                if (!item) return null;
                return item;
            },
            removeFromLocalStorage: function (key) {
                if (!this.browserSupportsLocalStorage()) {
                    return this.removeFromCookies(key);
                }

                try {
                    localStorage.removeItem(key);
                } catch (e) {
                    return this.removeFromCookies(key);
                }
                return true;
            },

            // **** cookie storage **** 

            browserSupportsCookies: function () {
                try {
                    return navigator.cookieEnabled ||
                      ("cookie" in document && (document.cookie.length > 0 ||
                      (document.cookie = "test").indexOf.call(document.cookie, "test") > -1));
                } catch (e) {
                    return false;
                }
            },
            addToCookies: function (key, value) {

                if (typeof value == "undefined") return false;

                if (!this.browserSupportsCookies()) {
                    return false;
                }

                try {
                    var expiry = '';
                    var expiryDate = new Date();

                    if (!value) {
                        this.cookie.expiry = -1;
                        value = '';
                    }
                    if (this.cookie.expiry !== 0) {
                        expiryDate.setTime(expiryDate.getTime() + (this.cookie.expiry * 24 * 60 * 60 * 1000));
                        expiry = "; expires=" + expiryDate.toUTCString();
                    }
                    if (!!key) {
                        document.cookie = key + "=" + encodeURIComponent(value) + expiry + "; path=" + this.cookie.path;
                    }
                } catch (e) {
                    return false;
                }
                return true;
            },
            getFromCookies: function (key) {
                if (!this.browserSupportsCookies()) {
                    return false;
                }

                var cookies = document.cookie.split(';');
                for (var i = 0; i < cookies.length; i++) {
                    var thisCookie = cookies[i].split(',')[0];
                    while (thisCookie.charAt(0) == ' ') {
                        thisCookie = thisCookie.substring(1, thisCookie.length);
                    }
                    if (thisCookie.indexOf(key + '=') === 0) {
                        return decodeURIComponent(thisCookie.substring(key.length + 1, thisCookie.length));
                    }
                }
                return null;
            },
            removeFromCookies: function (key) {
                this.addToCookies(key, null);
            },
            // **** json ****
            isJsonString: function (str) {
                try {
                    JSON.parse(str);
                } catch (e) {
                    return false;
                }
                return true;
            }
        }

        return storage;
    };

    service.$inject = ['$http', '$rootScope'];

    return service;
});