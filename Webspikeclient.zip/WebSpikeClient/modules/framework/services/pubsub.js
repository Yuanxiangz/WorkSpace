﻿define(function () {

    var service = function (storage) {
        var cache = {};
        return {
            publish: function (topic, args, skipCache) {

            	if (!skipCache) {
                    storage.addToSessionStorage(topic, angular.toJson(args));
                }

                cache[topic] && $.each(cache[topic], function () {
                    this.apply(null, args || []);
                });
            },

            subscribe: function (topic, callback, skipCache) {
                if (!cache[topic]) {
                    cache[topic] = [];
                }
                cache[topic].push(callback);

                var cachedValue = storage.getFromSessionStorage(topic);

                if (cachedValue && !skipCache) {

                	var j;

                	try {
                        j = JSON.parse(cachedValue);
                        if (typeof j === "number") {
                            j = [j];
                        }
                    }
                    catch (exception) {
                        j = [cachedValue];
                    }

                    callback.apply(null, j);
                }

                return [topic, callback];
            },

            //handle is the value returned from subsribe
            unsubscribe: function (handle) {
                if (handle) {
                    var t = handle[0];
                    cache[t] && $.each(cache[t], function (idx) {
                        if (this == handle[1]) {
                            cache[t].splice(idx, 1);
                        }
                    });
                }
            }
        }
    };

    service.$inject = ['storage'];

    return service;
});