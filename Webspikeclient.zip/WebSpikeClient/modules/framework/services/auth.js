﻿
define(['angular', 'lodash'],
function (angular, _) {
    'use strict';

    var authService = function ($http, $q, settings, storage) {
        this.glxToken = '';
        this.tokenRequested = false;

        var glxDeferred = $q.defer();
        //local 5B574B6E4EA44A8D802FE6158E7B5E1D
        //qaul2 7A9E67017AD247AC917A128A1A383E2D
        var getGlxURL = settings.apiEndpointHostname + 'perms/login?username=ANUCCIO&domain=SBDEMO&password=tal&appid=7A9E67017AD247AC917A128A1A383E2D&version=Boston';

        this.getGlxToken = function () {
            if (this.glxToken !== '') {
                glxDeferred.resolve(this.glxToken);
            } else {
                if (this.tokenRequested === false)
                    this.setGlxToken();
            }

            return glxDeferred.promise;
        };

        this.setGlxToken = function () {
            this.tokenRequested = true;
            $http.get(getGlxURL)
                .success(function (data, status, headers, config) {
                    glxDeferred.resolve(data.glx2);
                })
                .error(function (data, status, headers, config) {
                    glxDeferred.resolve('error');
                });
        };
    };
    
    authService.$inject = ['$http', '$q', 'settings', 'storage'];

    return authService;

});
