﻿define([],
function () {
    'use strict';

    var serviceFactory = [
		function () {

		    var getName = function getName() {
		        return "Eze Ims";
		    };

		    var getApiEndpointHostname = function getApiEndpointHostname() {
		        return 'https://qaul2.realtick.com/';
		    };

		    var getWebApiEndpointHostname = function getWebApiEndpointHostname() {
		        return 'http://devrotr.dev.local';
		    };

		    var settingsKeys = {
		        'streaming': {
		            'disconnected': 'streaming.disconnected',
		            'connected': 'streaming.connected'
		        },
		        'tradeblotter': {
		            'symbolselected': 'symbol.selected'
		        },
                'chart': {
                    'createchart': 'chart.create'
                }
		};

		    var getSettingsKeys = function getSettingsKeys() {
		        return settingsKeys;
		    };

		    return {
		        name: getName(),
		        apiEndpointHostname: getApiEndpointHostname(),
		        webApiEndpointHostname: getWebApiEndpointHostname(),
		        getSettingsKeys: getSettingsKeys()
		    };

		}
    ];

    return serviceFactory;

});