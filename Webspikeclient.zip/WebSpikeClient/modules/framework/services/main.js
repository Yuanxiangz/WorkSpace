﻿define(['angular',
        './settings',
        './auth',
        './streaming',
        './storage',
        './pubsub',
        'signalR',
        'hubs',
        './symbolSvc',
        './accounts',
		'./notification'
       ],
function (angular,
          settings,
          auth,
          streaming,
          storage,
          pubsub,
          signalr,
          hubs,
          symbolSvc,
          accounts,
		  notification) {
    'use strict';

    var frameworkServices = angular.module('webSpike.framework.services', []);

    frameworkServices.service('auth', auth);
    frameworkServices.factory('settings', settings);
    frameworkServices.factory('storage', storage);
    frameworkServices.factory('pubsub', pubsub);
    frameworkServices.service('streaming', streaming);
    frameworkServices.service('symbolSvc', symbolSvc);
    frameworkServices.service('accounts', accounts);

	frameworkServices.factory('notification', notification);


    return frameworkServices;

});