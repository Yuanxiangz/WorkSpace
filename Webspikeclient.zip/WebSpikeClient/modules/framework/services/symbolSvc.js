﻿define([],function () {
    "use strict";

    var service = function (storage, settings) {
        var apiHost = settings.apiEndpointHostname;
        var symbolSvc = {
            checksymbols: function (_featurename, glx, symbols, success, error) {
                var p_symbols = ($.isArray(symbols)) ? symbols.join(',') : symbols;
                return storage.async(apiHost + 'data/quote.checksymbols?feature=' + _featurename + '&glx=' + glx
                    + "&symbols=" + encodeURIComponent(p_symbols),
                    function (data, status, headers, config) {
                        success(data.Data);
                    },
                    error
                );
            },

            getsymboldata: function (_featurename, glx, symbol, success, error) {
                var arr_symbol = [symbol];

                var arr_columns = ["RIC_CODE", "BLOOMBERG_CODE", "CUSIP", "DISP_NAME", "ACVOL_1",
                                                                  "NETCHNG_1", "HIGH_1", "LOW_1", "BID",
                                                                  "BIDSIZE", "ASK", "ASKSIZE", "SYMBOL_DESC",
                                                                  "EXCH_NAME", "STYP", "PCTCHNG", "TRDPRC_1", "TRD_UNITS"];

                return storage.async(apiHost + 'data/quote.symlist?feature=' + _featurename + '&glx=' + glx
                    + "&symbols=" + encodeURIComponent(arr_symbol)
                    + "&columns=" + encodeURIComponent(arr_columns),
                    function (data, status, headers, config) {
                        success(data.Data);
                    },
                    error
                );
            }
        }

        return symbolSvc;
    };

    service.$inject = ['storage', 'settings'];

    return service;
});