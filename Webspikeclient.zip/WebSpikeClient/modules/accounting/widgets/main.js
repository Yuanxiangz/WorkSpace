﻿'use strict';

define(['angular', 'angularDashboard', './chart/chart-view', './chart/chart-edit'],
function (angular, angularDashboard, chartViewController, chartEditController) {

    var accountingWidgetsModule = angular.module('eze.accounting.widgets', ['adf.provider']);

    accountingWidgetsModule.config(function (dashboardProvider) {
        dashboardProvider
            .widget('Chart',
                {
                    title: 'Accounting Chart',
                    description: 'Accounting Chart',
                    templateUrl: 'modules/accounting/widgets/chart/chart-view.html',
                    controller: 'eze.accounting.widgets.chart-view.controller',
                    edit: {
                        templateUrl: 'modules/accounting/widgets/chart/chart-edit.html',
                        controller: 'eze.accounting.widgets.chart-edit.controller'
                    },
                    config: {
                        chartId: "GrossNettExposure"
                    }
                }
            );
    });

    accountingWidgetsModule.controller('eze.accounting.widgets.chart-view.controller', chartViewController);
    accountingWidgetsModule.controller('eze.accounting.widgets.chart-edit.controller', chartEditController);

    return accountingWidgetsModule;

});