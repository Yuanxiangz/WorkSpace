﻿define(function () {
    'use strict';

    function EzeAccountingWidgetChartViewController($http, $scope, settings) {

        $scope.chartOptions = $http.get(settings.webApiEndpointHostname + '/WebApiService/accounting/api/Charts/Definitions?documentID=' + $scope.config.reportId, { headers: { 'Accept': 'application/json' }
        })
            .success(function (data, status, headers, config) {
                $scope.chartOptions = data;
            })
            .error(function (data, status, headers, config) {
                $scope.chartOptions = data;
            });
    }

    EzeAccountingWidgetChartViewController.$inject = ['$http', '$scope', 'settings'];
    return EzeAccountingWidgetChartViewController;

});