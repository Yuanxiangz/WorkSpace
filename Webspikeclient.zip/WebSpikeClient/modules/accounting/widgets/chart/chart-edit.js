﻿define(function () {
    'use strict';

    function EzeAccountingWidgetChartEditController($scope) {
        $scope.chartId = 'GrossNettExposure';
    }

    EzeAccountingWidgetChartEditController.$inject = ['$scope'];
    return EzeAccountingWidgetChartEditController;

});