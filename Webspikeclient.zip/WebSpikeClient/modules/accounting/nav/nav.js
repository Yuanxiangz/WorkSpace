﻿
define(function () {
    'use strict';

    function AccountingNavController($scope) {

        $scope.treelistOptions = {
            dataSource: {
                type: "odata",
                transport: {
                    read: "http://demos.telerik.com/kendo-ui/service/Northwind.svc/Employees"
                },
                schema: {
                    model: {
                        id: "EmployeeID",
                        fields: {
                            parentId: { field: "ReportsTo", nullable: true },
                            EmployeeID: { field: "EmployeeID", type: "number" }
                        }
                    }
                }
            },
            sortable: true,
            editable: true,
            columns: [
                { field: "FirstName", title: "First Name", width: "150px" },
                { field: "LastName", title: "Last Name", width: "150px" },
                { field: "Title" },
                {
                    title: "Location",
                    template: "{{ dataItem.City }}, {{ dataItem.Country }}"
                },
                { command: ["edit"] }
            ]
        };
    }

    AccountingNavController.$inject = ['$scope'];

    return AccountingNavController;

});
