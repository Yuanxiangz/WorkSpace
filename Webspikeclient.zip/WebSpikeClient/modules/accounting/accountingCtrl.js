﻿define(function () {
    'use strict';

    function EzeAccountingController($scope) {
        console.log('EzeAccountingController');
        $scope.test = 'EzeAccountingController';
    }

    EzeAccountingController.$inject = ['$scope'];
    return EzeAccountingController;

});
