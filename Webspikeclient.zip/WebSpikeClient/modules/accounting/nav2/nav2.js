﻿
define(function () {
    'use strict';

    function AccountingNav2Controller($scope) {

        $scope.dataSource = new kendo.data.PivotDataSource({
            type: "xmla",
            columns: [{ name: "[Date].[Calendar]", expand: true }, { name: "[Product].[Category]" }],
            rows: [{ name: "[Geography].[City]" }],
            measures: ["[Measures].[Reseller Freight Cost]"],
            transport: {
                connection: {
                    catalog: "Adventure Works DW 2008R2",
                    cube: "Adventure Works"
                },
                read: "http://demos.telerik.com/olap/msmdpump.dll"
            },
            schema: {
                type: "xmla"
            },
            error: function (e) {
                alert("error: " + kendo.stringify(e.errors[0]));
            }
        });
        $scope.options = {
            columnWidth: 200,
            height: 580,
            dataSource: $scope.dataSource
        };
    }

    AccountingNav2Controller.$inject = ['$scope'];

    return AccountingNav2Controller;

});
