﻿
define(function () {
    'use strict';

    function accountingODataCtrl($scope, settings) {

        $scope.gridOptions = {

            dataSource: {
                type: "json",
                transport: {
                    read: {
                        url: settings.webApiEndpointHostname + "/WebApiService/accounting/api/Trades2",
                        dataType: "json"
                    },
                    //parameterMap: function (options, type) {
                    //    var paramMap = kendo.data.transports.odata.parameterMap(options);
                    //    delete paramMap.$inlinecount; // <-- remove inlinecount parameter
                    //    delete paramMap.$format; // <-- remove format parameter
                    //    return paramMap;
                    //},
                },
                pageSize: 15,
                serverPaging: true,
                serverSorting: true,
                serverGrouping: true,
                sortable: true,
                sort: ({ field: "tnum", dir: "desc" }),
                schema: {
                    data: function (data) {
                        return data.Items;
                    },
                    total: function (data) {
                        return data['Count']; // <-- The total items count is the data length, there is no .Count to unpack.
                    },
                    groups: function (data) {
                        return data.Items;
                    }
                }
            },
            groupable: true,
            sortable: true,
            pageable: {
                refresh: true,
                pageSizes: [10, 25, 50, 100, 200, 500, 1000, 10000],
                buttonCount: 5
            },
            scrollable: {
                virtual: true
            },
            columns: [{
                field: "tnum",
                title: "tnum",
                width: "120px"
            }, {
                field: "trader",
                title: "trader",
                width: "120px"
            }, {
                field: "tax",
                width: "120px"
            }, {
                field: "instructions",
                width: "120px"
            }, {
                field: "secId"
            }],
        }
      
    }

    accountingODataCtrl.$inject = ['$scope', 'settings'];

    return accountingODataCtrl;

});
