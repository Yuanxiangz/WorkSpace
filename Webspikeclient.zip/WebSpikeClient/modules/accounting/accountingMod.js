﻿
define(['angular', './widgets/main', './accountingCtrl', './summary/summary', './nav/nav', './nav2/nav2', './odata/odata'],
function (angular, widgets, accountingController, summaryController, navController, nav2Controller, odataController ) {
    'use strict';

    var accounting = angular.module('eze.accounting', [widgets.name]);

	accounting.controller('accountingCtrl', accountingController);
	accounting.controller('accountingSummaryCtrl', summaryController);
	accounting.controller('accountingNavCtrl', navController);
	accounting.controller('accountingNav2Ctrl', nav2Controller);
	accounting.controller('accountingODataCtrl', odataController);

	return accounting;

});
