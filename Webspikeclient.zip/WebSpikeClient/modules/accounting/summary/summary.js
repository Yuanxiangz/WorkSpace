﻿
define(function () {
    'use strict';

    function AccountingSummaryController($scope) {
        $scope.model = {};

        $scope.setDashboardModel = function () {
            $scope.model = {
                structure: "AccountingDashBoard",
             
                rows: [                    
                    {
                        columns: [
                            {
                                styleClass: "col-md-4 no-padding",
                                widgets: [{
                                    type: "Chart",
                                    title: "Long Short Performance Attribution",
                                    config: {
                                        reportId: 'LongShortPerformanceAttribution'
                                    }
                                },
								{
                                    type: "Chart",
                                    title: "Exposure By Market Sector",
                                    config: {
                                        reportId: 'ExposureByMarketSector'
                                    }
                                }]
                            },                           
                            {
                                styleClass: "col-md-4 no-padding",
                                widgets: [{
                                    type: "Chart",
                                    title: "Gross/Net Exposure",
                                    config: {
                                        reportId: 'GrossNetExposure'
                                    }
                                },
								{
                                    type: "Chart",
                                    title: "Exposure By Market Cap",
                                    config: {
                                        reportId: 'ExposureByMarketCap'
                                    }
                                }]
                            },
                            {
                                styleClass: "col-md-4 no-padding",
                                widgets: [{
                                    type: "Chart",
                                    title: "Exposure By Market Geography",
                                    config: {
                                        reportId: 'ExposureByMarketGeography'
                                    }
                                }]
                             }
                        ]
                    }
                ]
            };
        }


        $scope.init = function () {
            $scope.setDashboardModel();
        }

        $scope.init();
    }

    AccountingSummaryController.$inject = ['$scope'];

    return AccountingSummaryController;

});
