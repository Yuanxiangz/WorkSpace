
var isElectron= true;
try {
	window.$ = window.jQuery = require('./vendor/jquery/2.1.4/jquery.min');
	Sortable = require('./vendor/sortable/1.1.1/Sortable.min');
    require('remote').new 
}
catch(e) {
	isElectron = false;
}


requirejs.config({
    packages: [
        'framework',
        { name: 'framework', location: 'modules/framework', main: 'main' },
        { name: 'lodash', location: 'vendor/lodash' }
    ],
    waitSeconds: 30,
    paths: {
        angular: 'vendor/angular/1.4.0/angular',
        angularResource: 'vendor/angular/1.4.0/angular-resource.min',
        angularCookie: 'vendor/angular/1.4.0/angular-cookies.min',
        angularUiRouter: 'vendor/angular/1.4.0/angular-ui-router.min',
        angularDashboard: 'vendor/angular-dashboard/0.10.0/angular-dashboard-framework.min',
        bootstrap: 'vendor/bootstrap/3.3.4/js/bootstrap.min',
        uiBootstrap: 'vendor/ui-bootstrap/0.13.0/ui-bootstrap-tpls-0.13.0.min',
        sortable: 'vendor/sortable/1.1.1/sortable',
        kendo: 'vendor/telerik/kendo/2015.1.408/js/kendo.all.min',
        reporting: 'vendor/telerik/reporting/9.0.15.324/html5/js/telerikReportViewer-9.0.15.324',
        signalR: 'vendor/signalr/signalr',
        moment: 'vendor/moment/moment-with-locales.min',
        hubs: 'vendor/signalr/hubs',
        jquery: 'vendor/jquery/2.1.4/jquery.min',
        angularHotkeys: 'vendor/angular-hotkeys/1.4.5/build/hotkeys.min',
        highcharts: 'vendor/highcharts/highcharts'
    },
    shim: {
        'angular': {
            deps: ['jquery'],
            exports: 'angular'
        },
        'angularResource': {
            deps: ['angular']
        },
        'angularCookie': {
            deps: ['angular']
        },
        'angularUiRouter': {
            deps: ['angular']
        },
        'angularDashboard': {
            deps: ['angular', 'sortable']
        },
        'bootstrap': {
            deps: ['jquery']
        },
        'uiBootstrap': {
            deps: ['angular']
        },
        'kendo': {
            deps: ['angular', 'jquery']
        },
        'reporting': {
            deps: ['kendo', 'jquery']
        },
        'signalR': {
            deps: ['jquery']
        },
        'hubs': {
            deps: ['jquery', 'signalR']
        },
		'moment': {
			
        },
		'moment-timezone': {

		},
		'angularHotkeys': {
			deps: ['angular']
		},
        'highcharts': {
            exports: 'Highcharts'
        }
    },
    priority: [
        "angular"
    ]
});


//http://code.angularjs.org/1.2.1/docs/guide/bootstrap#overview_deferred-bootstrap
window.name = "NG_DEFER_BOOTSTRAP!";
requirejs(['app', 'angular'], function (app, angular) {
    var $html = angular.element(document.getElementsByTagName('html')[0]);
    angular.element().ready(function () {
        var moduleNames = [];
        moduleNames.push(app["name"]);
        angular.resumeBootstrap(moduleNames);
    });
});
//# sourceMappingURL=config.js.map