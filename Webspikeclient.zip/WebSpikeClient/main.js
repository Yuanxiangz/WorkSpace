
// ReSharper disable Es6Feature
'use strict';
const app = require('app');  // Module to control application life.
const BrowserWindow = require('browser-window');  // Module to create native browser window.
const globalShortcut = require('global-shortcut');
const nativeImage = require('native-image');
const Tray = require('tray');
const Menu = require('menu');
const ipc = require('ipc');


var ezeIcon = __dirname + '/eze.png';

// Report crashes to our server.
require('crash-reporter').start();

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the javascript object is GCed.
var mainWindow = null;
global["trayIcon"] = null;

// Quit when all windows are closed.
app.on('window-all-closed', function () {
	if (process.platform !== 'darwin') app.quit();
});

// Keep a reference to all windows.
let windows = [];


// This method will be called when Electron has done everything
// initialization and ready for creating browser windows.
app.on('ready', function () {

	// Create the browser window.
    mainWindow = new BrowserWindow({ width: 1600, height: 900, frame: false, icon: ezeIcon });
    windows.push(mainWindow);

	// and load the index.html of the app.
	mainWindow.loadUrl('file://' + __dirname + '/index.html');

	// Open the devtools.
    //mainWindow.openDevTools();

	// Emitted when the window is closed.
	mainWindow.on('closed', function() {
		// Dereference the window object, usually you would store windows
		// in an array if your app supports multi windows, this is the time
		// when you should delete the corresponding element.
		mainWindow = null;
	});

	let chartWindow = null;

	ipc.on('launchChartWindow', function (event, arg) {
	    console.log(arg);
	    if (chartWindow === null) {
	        chartWindow = new BrowserWindow({ width: 1000, height: 800, frame: false });
	        windows.push(chartWindow);
	    }
	    chartWindow.loadUrl('file://' + __dirname + '/index.html#/popout/trading/chart-window?DISP_NAME=' + arg.DISP_NAME);
	    chartWindow.setTitle('Chart ' + arg.DISP_NAME);
	});

	ipc.on('launchEquityOrderTicketWindow', function (event, arg) {
	    console.log(arg);
	    let ticketWindow = new BrowserWindow({ width: 900, height: 1040, frame: false });
	    windows.push(ticketWindow);
	    ticketWindow.loadUrl('file://' + __dirname + '/index.html#/popout/trading/equity-order-ticket-window?&DISP_NAME='+ arg.DISP_NAME);
	    ticketWindow.setTitle('Equity Order Ticket for ' + arg.DISP_NAME);
	});

    var registerShortcut = function() {
        return globalShortcut.register('F5', function () {
            var ticketWindow = new BrowserWindow({ width: 800, height: 920, frame: false  });
            ticketWindow.setTitle('Equity Order Ticket');
			
            ticketWindow.loadUrl('file://' + __dirname + '/index.html#/popout/trading/equity-order-ticket-window');
            windows.push(ticketWindow);
        });
    };
    registerShortcut();


	mainWindow.on('focus', function() {
	    registerShortcut();
	});

	mainWindow.on('blur', function() {
		globalShortcut.unregister('F5');
	});

	var trayIcon = global["trayIcon"] = new Tray(__dirname + '/images/windows-system-tray.png');

	var contextMenu = Menu.buildFromTemplate([
	  { label: 'Item1', type: 'radio' },
	  { label: 'Item2', type: 'radio' },
	  { label: 'Item3', type: 'radio', checked: true },
	  { label: 'Item4', type: 'radio' }
	]);

	trayIcon.setToolTip('This is my application.');

	trayIcon.setContextMenu(contextMenu);

});
// ReSharper restore Es6Feature
