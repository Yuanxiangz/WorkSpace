﻿define([], function () {
    'use strict';
    return function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attrs, modelCtrl) {

                var transform = function transform(input) {
                    if (input == null) {
                        return null;
                    }
                    if (input.toString().indexOf('k') > 0) {
                        return parseFloat(input) * 1000;
                    }
                    if (input.toString().indexOf('m') > 0) {
                        return parseFloat(input) * 1000000;
                    }
                    else {
                        return input;
                    }
                };

                modelCtrl.$parsers.push(function intelligentKeystrokesParser(input) {
                    var transformedInput = transform(input);
                    element.val(transformedInput);
                    return transformedInput;
                });

                modelCtrl.$formatters.push(function intelligentKeystrokesParser(input) {
                    var transformedInput = transform(input);
                    element.val(transformedInput);
                    return transformedInput;
                });

                element.css("text-transform", "intelligent-keystrokes");
            }
        };
    }
});