﻿define([], function () {
    'use strict';

    var createKendoGrid = function (scope, attrs, element, grid, columns) {
        if (!scope.gridInitialized) {   //if first init
            var $currElement = $(element);
            var currKendoGrid = $currElement.kendoGrid({
                        dataSource: {
                            data: grid,
                            pageSize: 15
                        },
                        allowCopy: true,
                        scrollable: {
                            virtual: true
                        },
                        sortable: true,
                        filterable: true,
                        navigatable: true,
                        reorderable: true,
                        columnMenu: true,
                        resizable: true,
                        groupable: true,
                        selectable: 'row',
                        pageable: scope.$eval(attrs.ezeGridPageable),
                        columns: columns,
                        change: function () {
                            var orderID = '';
                            var selected = $.map(this.select(), function (item) {
                                orderID = $(item).find('.order-id-cell').text();    //grabs the cell containing the symbol name                    
                            });
                            scope.$apply(
                                function () {
                                    scope.$eval(attrs.onSelect + '(\'' + orderID + '\')');    //needs to be called this way to get the digest cycle initiated
                                });            
                        }
            }).data('kendoGrid');
            
            //this makes the row draggable in the grid
            currKendoGrid.table.kendoDraggable({
                filter: "tbody > tr",
                group: "orderGroup",
                cursorOffset: {top: -10, left: -90},    //-90 so the cursor is on the top right of the draggable unit
                hint: function(e) {
                    var $event = $(e);
                    var buyorsell = $event.find('.kendo-buyorsell-label')[0].outerHTML;     //get the buy or sell label
                    var volume = $event.find('.volume-cell').html();
                    var dispName = $event.find('.disp-name-cell').html();

                    var htmlToReturn = $('<div class="k-grid k-widget row-drag"><table><tbody>' 
                                        + '<tr><td><span class="drag-buy-or-sell">' + buyorsell + '</span></td></tr>' 
                                        + '<tr><td><span class="drag-volume">' + volume + ' shares</span></td></tr>' 
                                        + '<tr><td><span class="drag-disp-name">' + dispName + '</span></td></tr>' 
                                        + '</tbody></table></div>');
                    return htmlToReturn;
                }
                    });   

        } else {    //update the data
            var kendoEl = $(element).data('kendoGrid');
            kendoEl.dataSource.data(grid);
            kendoEl.refresh();
        }
             
    }

    var ezeGrid = function () {
        return {
            restict: "EA",
            template: "<div class='grid-directive'></div>",
            replace: true,
            link: function (scope, element, attrs) {
                var gridAttr = attrs.coldata;
                var gridWatchHandle;

                var columns = scope.$eval(attrs.collist);              
                gridWatchHandle = scope.$watchCollection(gridAttr, function (newValue, oldValue) {
                    if (newValue !== oldValue) {
                        createKendoGrid(scope, attrs, element, newValue, columns);
                        if (!scope.gridInitialized) 
                            scope.gridInitialized = true;
                    }
                });
            }
        };
    };

    return ezeGrid;

});