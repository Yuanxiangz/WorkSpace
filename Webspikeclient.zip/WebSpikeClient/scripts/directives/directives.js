﻿
define(['angular', './ezeGrid', './buyOrSellLabel', './sparkLine', './uppercased', './intelligentKeystrokes','./dropTarget'],
    function (angular, ezeGrid, buyOrSellLabel, sparkLine, uppercased, intelligentKeystrokes, dropTarget) {

        var directives = angular.module('directives', []);

        directives.directive('buyOrSellLabel', buyOrSellLabel);
        directives.directive('ezeGrid', ezeGrid);
        directives.directive('uppercased', uppercased);
        directives.directive('sparkLine', sparkLine);
        directives.directive('dropTarget', dropTarget);
        directives.directive('intelligentKeystrokes', ['$parse', intelligentKeystrokes]);


        return directives;
    });