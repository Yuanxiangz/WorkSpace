﻿define(['lodash'], function (_) {
	'use strict';

	var sparkLine = function () {
		function link(scope, element, attrs) {
			function updateSparkLine() {
				var currData = scope.$eval(attrs.sparkLine);
				if (currData) {
					$(element).kendoSparkline({
						type: "line",
						data: _.map(currData, function(point) {
							return point.SETTLE;
						})
					});
				}                
			}

			scope.$watch(attrs.sparkLine, function (data) {
				updateSparkLine();
			})

		}
		return {
			link: link
		};
	};

	return sparkLine;

});