define(['lodash'], function (_) {
    'use strict';

    var dropTarget = function (accounts, $modal) {
        function link(scope, element, attrs) {
            var $currElement = $(element);
            var onDropFunc = attrs.dropTarget;

            $currElement.kendoDropTarget({
                group: 'orderGroup',
                drop: function(e) {
                    var buyorsell = $(e.draggable.hint).find('.kendo-buyorsell-label').html();
                    var volume = $(e.draggable.hint).find('.drag-volume').html();
                    var dispName = $(e.draggable.hint).find('.drag-disp-name').html();
                    var currOrder = {
                        buyorsell: buyorsell,
                        volume: volume,
                        dispName: dispName
                    }

                    //grab the current row that is selected
                    var fullGrid = $('.trading-order-blotter').data('kendoGrid');
                    var rowData = fullGrid.dataItem(fullGrid.select());
                    
                    //if it is a staged order (CURRENT_BBCD was hardcoded to staged orders)
                    var currBBCD = (rowData) ? rowData.CURRENT_BBCD : null;
                    if (currBBCD) {
                        currOrder.BBCD = currBBCD;
                        var bbcdSeparate = currBBCD.split(';');
                        if (bbcdSeparate.length > 3) {
                            var currAccount = {
                                Bank: bbcdSeparate[0],
                                Branch: bbcdSeparate[1],
                                Customer: bbcdSeparate[2],
                                Deposit: bbcdSeparate[3]
                            }
                            accounts.getRoutes(currAccount).then(
                                function(routes) {
                                    $modal.open({       //open up modal to select route to execute trade
                                        templateUrl: 'modules/trading/widgets/order-commit/_order-drop-target.html',
                                        controller: 'orderCommitDropCtrl',
                                        backdrop: 'static',
                                        size: 'sm',
                                        resolve: {
                                            routes: function() { return routes; },
                                            order: function() { return currOrder;}
                                        }                                       
                                    });
                            });
                        }                        
                    }
                } //end dragenter

            });

        }

        return {
            link: link           
        };
    };

    return dropTarget;

});