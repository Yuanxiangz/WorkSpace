﻿define([], function () {
    'use strict';

    var buyOrSellLabel = function () {
        function link(scope, element, attrs) {
            function updateLbl() {
                var buyorsell = scope.$eval(attrs.buyorsell);
                var lblClass = '';
                switch (buyorsell) {
                    case 'BUY':
                        lblClass = 'label-success';
                        break;
                    case 'SELL':
                        lblClass = 'label-danger';
                        break;
                    case 'SELLSHORT':
                        buyorsell = 'SHORT';
                        lblClass = 'label-warning';
                        break;
                    case 'COVER':
                        buyorsell = 'COVER';
                        lblClass = 'label-cover';
                        break;
                }

                var htmlToReturn = '<span class="kendo-buyorsell-label label ' + lblClass + ' ">' + buyorsell + '</span>';

                element.html(htmlToReturn);
            }
            
            scope.$watch(attrs.buyorsell, function () {
                updateLbl();
            })

        }
        return {
            link: link            
        };
    };

    return buyOrSellLabel;

});