
define(['angular'], function (angular) {

    var filters = angular.module('filters', []);

    filters.filter('reverse', function () {
        return function (items) {
            return items.slice().reverse();
        };
    });

    filters.filter('orderByStrike', function () {
        return function (obj) {
            var array = [];
            if (obj) {
                Object.keys(obj).forEach(function (key) {
                    array.push(obj[key]);
                });
                array.sort(function (a, b) {
                    return Number(a[0].STRIKE_PRC.replace(',', '')) - Number(b[0].STRIKE_PRC.replace(',', ''));
                });
            }
            return array;
        }
    });


    filters.filter('orderObjectBy', function () {
        return function (items, field, numeric, reverse) {
            var filtered = [];
            angular.forEach(items, function (item) {
                filtered.push(item);
            });
            if (numeric) {
                filtered.sort(function (a, b) {
                    return a[field] - b[field];
                });
            } else {
                filtered.sort(function (a, b) {
                    if (a[field] > b[field]) return 1;
                    if (a[field] < b[field]) return -1;
                    return 0;
                });
            }
            if (reverse) filtered.reverse();
            return filtered;
        };
    });

    return filters;

});
