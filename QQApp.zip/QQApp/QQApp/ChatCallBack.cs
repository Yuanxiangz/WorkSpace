﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QQApp
{
    class ChatCallBack//: IChatCallBack
    {
        public void UserEnter(string name)
        {
            throw new NotImplementedException();
        }

        public void UserLeave(string name)
        {
            throw new NotImplementedException();
        }
    }
}
