﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1.Data
{
	public enum QuestionType
	{
		None,
		Distance,
		StartEndMaxStops,
		StartEndExactStops,
		StartEndShortest
	}
}
