﻿
namespace Problem2.Data
{
	public enum TimeSchduleStrategy
	{ 
		EfficiencyFirst,
		TimeUtilizitionFirst
	}
}
