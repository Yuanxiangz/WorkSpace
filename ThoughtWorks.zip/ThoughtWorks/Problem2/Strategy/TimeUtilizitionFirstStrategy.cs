﻿using System.Collections.Generic;
using Problem2.Data;

namespace Problem2.Strategy
{
	public class TimeUtilizitionFirstStrategy : AbstractStrategry
	{
		public override IEnumerable<DaySchedule> Schedule(IList<ScheduleItem> requests)
		{
			return null;
		}
	}
}
